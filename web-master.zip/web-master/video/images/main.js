var bEditChanged=false;
function editChanged(){
	bEditChanged=true;
}
function ignoreChanged(){
	if(!bEditChanged || confirm('�������༭��������')){
		return true;
	}else{
		return false;
	}
}
String.prototype.rot13 = function(){
	return this.replace(/[a-zA-Z]/g, function(c){
		return String.fromCharCode((c <= "Z" ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26);
	});
};
function d(s){
	if(!s)return '';
	var k=new RegExp('\\'+s.charAt(s.length-1),"g");
	s=s.substring(0,s.length-1);
	s=s.replace(k,'%');
	return decodeURIComponent(s.rot13());
}
function getDocWidth(defaultWidth){
	var d=document.body;
	var w=d?parseInt(d.scrollWidth?d.scrollWidth:(d.offsetWidth?d.offsetWidth:d.clientWidth))-20:0;
	return w?w:defaultWidth;
}
function closetips(e){
	document.cookie='clst=1';
	e.parentElement.style.display="none";
}

var video_item_begin=0, video_item_end=0, video_shoudpause=false;
function play(id,file,ext,image,title,width,height,autostart,isVideolist,onfinish){
	if(isVideolist){
		showPlayerList(file, id, null, false, width, height, null, 'v_play');
	}else{
		var is_audio = ext=='mp3';
		jwplayer('v_play').setup({
			'title':title,
			'image':is_audio?null:image,
			'file':file,	
			'width':width,
			'height':is_audio?40:height,
			'controls': true,
			'type':is_audio?ext:'mp4',
			'primary':'html5',
			'fallback':true,
			'allowscriptaccess':'always',
			'startparam': "starttime",
			'autostart':autostart,
			'analytics':{enabled:false, cookies:false}
		});
	}
	onfinish=typeof(onfinish)==='function'?onfinish:null;
	jwplayer().onTime(function(e){
		if(video_shoudpause || (video_item_end>0 && e.position>video_item_end)){
			video_shoudpause=false;
			video_item_end=0;
			jwplayer().pause(true);
		}
		if(onfinish && e.duration-e.position<60 && e.position>e.duration*2/3) {onfinish();onfinish=null;}
	});
	jwplayer().onBeforeComplete(function(){
		if(onfinish){
			onfinish();
			onfinish=null;
		}
	});
}
function play2(pos1,pos2){
	video_item_begin=typeof(pos1)==='undefined'?0:pos1;
	video_item_end=typeof(pos2)==='undefined'?0:pos2;
	jwplayer().seek(video_item_begin);
	jwplayer().play(true);
}
