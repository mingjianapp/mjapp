<?php
/**

�ӿ���;��
���� /video/ ҳ��Ӱ���б�

���÷�ʽ��
ֱ�ӷ���  "����/video/json.php"  ��  "����/video/json.php?keyword=�ؼ���(��ѡ)"

��Ӧ���ݣ�
�������¸�ʽ���ݾ���juyuange���ܺ���ı�
{
"count":Ӱ������,
"keyword":"����ؼ���",
"list":[
    {"title":"����", "keyword":"�ؼ���", "image":"����ͼ", "video":[Ӱ���ļ���ַ������], "subtitle":[Ӱ���ļ��ӱ��������]},
    {"title":"����", "keyword":"�ؼ���", "image":"����ͼ", "video":[Ӱ���ļ���ַ������], "subtitle":[Ӱ���ļ��ӱ��������]},
    ...
    ]
}

*/

require('inc.php');
require(INCLUDE_DIR.'/charset.inc.php');
header('Content-Type: text/plain; Charset=utf-8');

$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
if($keyword){
    $keyword = rawurldecode(juyuange_decrypt($keyword));
    if(Charset::isUtf8($keyword)) $keyword=mb_convert_encoding($keyword, 'gbk', 'utf-8');
}

refetch_video_list();
$playlist = unserialize(@file_get_contents(LIST_FILE));
if(empty($playlist)) $playlist=array();

foreach($playlist as $k=>$v){
	if(!is_array($v) ||
	   !$v['canplay'] ||
	   !$v['show'] ||
	   ($keyword && !in_array($keyword, $v['keyword'])))
	{
        unset($playlist[$k]);
        continue;
	}

	$v['title'] = mb_convert_encoding($v['title'], 'utf-8', 'gbk');
	$v['keyword'] = mb_convert_encoding(implode(',', $v['keyword']), 'utf-8', 'gbk');
    $v['image'] = !empty($v['image']) ? get_thumb_url_2($v['image'],$v['proxy']) : "{$app_path}images/thumb_mp3.gif";

    $videolist = empty($v['videolist']) ? playlist_extract_list($v['video'],false) : $v['videolist'];
    $subtitle = $video = array();
	foreach($videolist as $k2=>$v2){
	    $subtitle[] = $v2[0] ? mb_convert_encoding($v2[0], 'utf-8', 'gbk') : '';
	    $video[] = get_real_url_2($v2[1],$v['proxy']);
	}
	unset($v['proxy'], $v['canplay'], $v['show'], $v['desc'], $v['videolist'], $v['video']);
	$v['video'] = $video;
	$v['subtitle'] = $subtitle;
    $playlist[$k] = $v;
}

$data = array(
    'count'=>count($playlist),
    'keyword'=>mb_convert_encoding($keyword, 'utf-8', 'gbk'),
    'list'=>array_values($playlist)
);

$data = json_encode($data);
echo juyuange_encrypt($data);


//==============================================================================

function add_domain($uri){
    return ($uri[0]=='/') ? $GLOBALS['site_url'].$uri : $uri;
}


function get_real_url_2($url, $proxy){
    global $video_path;
    if(!$url){
        return null;
    }elseif(!isset($url[1])){
        return $url;
    }elseif(strpos($url,'://')){
        //
    }elseif(substr($url,0,2)=='//'){
        $url = (!empty($_SERVER['REQUEST_SCHEME'])?$_SERVER['REQUEST_SCHEME']:'http') . ":{$url}";
    }elseif($url[0]!='/' && file_exists(DIR."/video/{$url}")){
        $url = $site_url."/video/{$url}";
    }elseif(strpos($url,'_ytb')!==false && preg_match('#^/(_ytbl?/|\?_ytbl?=)#', $url)){
        return $url;
    }elseif($url[0]=='/' && substr($video_path,-1)=='/'){
        //
    }else{
        $url = $video_path.$url;
    }

    if(preg_match('#^/res((?:/[\w\-]+){1,4})(\.mp4|\.mp3|\.m3u8)$#', $url, $match)){
        return '/res-' . juyuange_encrypt($match[1]) . $match[2];
    }elseif($proxy && strpos($url,'://')){
        return encrypt_url_2nd($url,true,false);
    }else{
        return $url;
    }
}

function get_thumb_url_2($url, $proxy){
    static $thumbs_cache = array();
    if(isset($thumbs_cache[$url])){
        return $thumbs_cache[$url];
    }
    $original_url = $url;
    $url = str_replace(array("\0","\n","\r","\t","\"","'"), '', $url);

    global $site_url, $thumb_path, $app_path, $config;
    if(!isset($url[1])){
        $thumbs_cache[$original_url] = $url;
        return $url;
    }elseif(strpos($url,'://')){
        //
    }elseif(substr($url,0,2)=='//'){
        $url = (!empty($_SERVER['REQUEST_SCHEME'])?$_SERVER['REQUEST_SCHEME']:'http') . ":{$url}";
    }elseif($url[0]=='/' && file_exists(PARENT_DIR.$url)){
        $url = $site_url.$url;
    }elseif($url[0]=='/' && substr($thumb_path,-1)=='/'){
        //
    }elseif(strpos($url,'/')===false && !file_exists(DIR.'/thumb/'.$url) && !empty($config['sync_server']) && strpos($config['sync_server'],$site_url)===false){
        //���ķ������ļ�
        $proxy = true;
        $filename = $url;
        $url = rtrim($config['sync_server'],'/') . '/video/thumb/' . $url;
    }else{
        $url = $thumb_path.$url;
    }

    if(preg_match('#^/res((?:/[\w\-]+){1,4})(\.(?:png|jpg|gif|jpeg))$#', $url, $match)){
        return '/res-' . juyuange_encrypt($match[1]) . $match[2];
    }elseif($proxy && strpos($url,'://')){
        //$url = encrypt_url_2nd($url,true,false); ��Ϊ�·��Ļ��淽��
        $ext = fileext($url);
        if(!preg_match('#^\.(jpg|jpeg|gif|png)$#', $ext)){
            $ext = '';
        }
        if(empty($filename)) $filename = '~'.md5($url).$ext;
        $local_file = DIR.'/thumb/'.$filename;
        $local_url = $thumb_path.$filename;
        if(file_exists($local_file) && filemtime($local_file)>strtotime('-7 day')){
            //�ѻ����ڱ���
            $url = $local_url;
        }else{
            //����ͼƬ
            include_once(INCLUDE_DIR.'/http.inc.php');
            if(class_exists('Http')){
                $data = Http::getHtml($url, null, null, false, $config);
                if($data && file_put_contents($local_file, $data)){
                    $url = $local_url;
                }else{
                    $url = $app_path.'images/thumb_mp3.gif';
                }
            }else{
                $url = encode_external_url($url);
            }
        }
    }
    $thumbs_cache[$original_url] = $url;
    return $url;
}

