<?php
include('config.inc.php');

defined('DEBUGING') or define('DEBUGING', 0);
defined('APP_CHARSET') or define('APP_CHARSET', 'GBK');
define('COOKIE_VISIT', 'v_visit'); //����ͳ��
define('COOKIE_PLAY', 'v_play'); //����ͳ��
define('COOKIE_FINISH', 'v_finish'); //�������ͳ��
define('DIR', dirname(__FILE__));
define('PARENT_DIR', dirname(DIR));
define('APPDIR', PARENT_DIR);
define('DATADIR', PARENT_DIR . '/data');
define('INCLUDE_DIR', PARENT_DIR.'/include');
define('TEMPDIR', PARENT_DIR.'/temp');
define('LIST_FILE', DATADIR.'/video.dat'); //�б��ļ�
define('PLAY_COUNTER_FILE', DATADIR.'/~counter_play_video.dat'); //����ͳ���ļ�
define('VISIT_COUNTER_FILE', DATADIR.'/~counter_visit_video.dat'); //����ͳ���ļ�
error_reporting(DEBUGING ? E_ALL | ~E_NOTICE : E_ERROR);
if(DEBUGING) @ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

if(version_compare(PHP_VERSION, '5.3.3', '<')){
	exit('Need PHP 5.3.3 or higher!');
}
if(!function_exists('mb_convert_encoding')){
	exit('����֧�� mb_convert_encoding ������');
}

if(!include(INCLUDE_DIR.'/global.inc.php')) exit('û�ҵ� global.inc.php �ļ�');

//��������
include(PARENT_DIR.'/config.inc.php');
$enable_bottom_nav = isset($bottom_navigation['enable']) ? $bottom_navigation['enable'] : false;
$config_admin_password = !empty($config['password']) ? $config['password'] : '';
require(INCLUDE_DIR.'/func.inc.php');
require(INCLUDE_DIR.'/http.inc.php');
require(INCLUDE_DIR.'/coding.inc.php');

//�����Զ�����
if($config['plugin'] && file_exists(APPDIR."/plugin/{$config['plugin']}.php")){
	require(APPDIR."/plugin/{$config['plugin']}.php");
}

forbid_spider();
init_config();
$time = time();
$site_url = get_current_homepage();
$app_path = get_current_site_path();
$search = array('{path}', '{server}');
$replace = array(substr($app_path,0,-1), isset($_SERVER['HTTP_HOST'])?"//{$_SERVER['HTTP_HOST']}":"//{$_SERVER['SERVER_NAME']}");
$video_path = isset($video_path) ? str_replace($search, $replace, $video_path) : "{$app_path}video/";
$thumb_path = isset($thumb_path) ? str_replace($search, $replace, $thumb_path) : "{$app_path}thumb/";

if(!isset($remote_video_server) || strpos($remote_video_server,$site_url)!==false){
    $remote_video_server = '';
}
header('Content-Type: text/html; charset='.APP_CHARSET);

//==========================================================================

//ÿ�ո���һ��Ӱ���б��ļ�
function refetch_video_list(){
    global $remote_video_server, $site_url, $app_path, $config;
    if($remote_video_server && (!file_exists(LIST_FILE) || time()-filemtime(LIST_FILE)>86400)){
        touch(LIST_FILE); //�����ڸ����ڼ䱻��������ͬʱ����
        $data = serialize(array('md5'=>md5_file(LIST_FILE), 'gz'=>function_exists('gzdecode'), '_'=>time()));
        $pwd1 = md5_16(DEFAULT_JYG_PASSWORD.$site_url.$app_path);
        $data = juyuange_encrypt($data, $pwd1);
        $pwd2 = md5_16(DEFAULT_JYG_PASSWORD.$data.$site_url.$app_path);
        $data = http_post($remote_video_server, "v1={$data}", array('timeout'=>15, 'referer'=>$site_url.$app_path, 'proxy'=>$config['proxy']));
        if(trim($data)==''){
            //������������10���Ӻ�����
            touch(LIST_FILE, time()-86400+600);
        }elseif($data=='304'){
            //û�仯
        }else{
            $gz = $data[0]=='1';
            $data = substr($data, 1);
            $data = $data ^ str_pad($pwd2,strlen($data),$pwd2);
            $data = str_decrypt($data);
            if($gz) $data=gzdecode($data);
            if(!empty($data) && substr($data,0,2)=='a:' && substr($data,-1)=='}' && strpos($data,'"title"')>0 && strpos($data,'s:6:"lastid";i:')>0 && is_array(unserialize($data))){
                file_put_contents(LIST_FILE, $data);
            }
        }
    }
}

function get_real_url($url, $proxy){
    global $video_path, $config;
	static $urlCoding = null;
	if(!$url){
		return null;
	}elseif(!isset($url[1])){
		return $url;
	}elseif(strpos($url,'://')){
		//
	}elseif(substr($url,0,2)=='//'){
		$url = (!empty($_SERVER['REQUEST_SCHEME'])?$_SERVER['REQUEST_SCHEME']:'http') . ":{$url}";
	}elseif($url[0]!='/' && file_exists(DIR."/video/{$url}")){
		return "/video/{$url}";
	}elseif(strpos($url,'_ytb')!==false && preg_match('#^/(_ytbl?/|\?_ytbl?=|\?'.$config['built_in_name'].'=_ytbl?_)([\w\-\.]+)(\?|&|\.\w{2,4}$|$)#', $url, $match)){
	    $str = (strpos($match[1],'ytbl')!==false ? '_ytbl_' : '_ytb_') . $match[2];
	    return "/?{$config['built_in_name']}=" . encrypt_builtin($str);
	}elseif(function_exists('my_decodeUrl') && preg_match('#^/res(/[\w\-\/]+|_\w{2,200})\.mp[34]$#', $url) && ($s=my_decodeUrl($url))){
		$url = $s;
	}elseif($url[0]=='/' && substr($video_path,-1)=='/'){
		return $url;
	}else{
	    $url = $video_path.$url;
	}

	if($proxy && strpos($url,'://')){
		if($urlCoding===null){
			$currentUrl = Url::getCurrentUrl();
			$remoteUrl = null;
			$urlCoding = new UrlCoding($currentUrl, $remoteUrl);
			$urlCoding->ignoreWhiteDomains = true;
		}
		$url = $urlCoding->encodeUrl($url, 'media', null, true);
		return $url;
	}else{
		return $url;
	}
}

function get_thumb_url($url, $proxy){
    static $thumbs_cache = array();
    if(isset($thumbs_cache[$url])){
        return $thumbs_cache[$url];
    }
    $original_url = $url;
    $url = str_replace(array("\0","\n","\r","\t","\"","'"), '', $url);

    global $site_url, $thumb_path, $app_path, $config;
    if(!isset($url[1])){
        $thumbs_cache[$original_url] = $url;
        return $url;
    }elseif(substr($url,0,2)=='//'){
        $url = "http:{$url}";
    }elseif($url[0]=='/' && file_exists(PARENT_DIR.$url)){
        $thumbs_cache[$original_url] = $url;
        return $url;
    }elseif(strpos($url,'://')){
        //
    }elseif(strpos($url,'/')===false && !file_exists(DIR.'/thumb/'.$url) && !empty($config['sync_server']) && strpos($config['sync_server'],$site_url)===false){
        //���ķ������ļ�
        $proxy = true;
        $filename = $url;
        $url = rtrim($config['sync_server'],'/') . '/video/thumb/' . $url;
    }else{
        $url = $thumb_path.$url;
    }
    if($proxy && strpos($url,'://')){
        $ext = fileext($url);
        if(!preg_match('#^\.(jpg|jpeg|gif|png)$#', $ext)){
            $ext = '';
        }
        if(empty($filename)) $filename = '~'.md5($url).$ext;
        $local_file = DIR.'/thumb/'.$filename;
        $local_url = $thumb_path.$filename;
        if(file_exists($local_file) && filemtime($local_file)>strtotime('-7 day')){
            //�ѻ����ڱ���
            $ret = $local_url;
        }else{
            //����ͼƬ
            include_once(INCLUDE_DIR.'/http.inc.php');
            if(class_exists('Http')){
                $data = Http::getHtml($url, null, null, false, $config);
                if($data && file_put_contents($local_file, $data)){
                    $ret = $local_url;
                }else{
                    $ret = $app_path.'images/thumb_mp3.gif';
                }
            }else{
                $ret = encode_external_url($url);
            }
        }
    }else{
        $ret = $url;
    }
    $thumbs_cache[$original_url] = $ret;
    return $ret;
}

function head($title, $other_head=null){
    global $app_path;
	$extCSS = defined('IN_FRAME')?'body{background:none; margin:0; padding:0;} #container{width:auto; margin:0;}':'';
	$page_id = isMobile()?'page_mobile':'';
	echo <<<EOH
<!DOCTYPE html><html><head>
<meta http-equiv="Content-Type" content="text/html; charset=GBK" />
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<title>{$title}</title>
<link href="{$app_path}images/style.css" rel="stylesheet" type="text/css">
<style type="text/css">{$extCSS}</style>
<script type="text/javascript">
function G(id){return document.getElementById(id);}
function V(id){var o=document.getElementById(id); if(!o)return; o.style.display=(o.style.display=='none'?'block':'none');}
</script>
{$other_head}
</head>
<body id="{$page_id}">
<div id="container">
EOH;
	if(!defined('IN_FRAME')){
		echo <<<EOH
	<div id="header"><img src="{$app_path}images/bg_header.gif" width="800" style="display:none;" onload="this.style.display='block'" border="0" alt="{$title}" /></div>
	<div id="main">
EOH;
	}
}

function foot($str=null){
    global $app_path;
	if(!defined('IN_FRAME')){
		echo <<<EOF
	</div>
	<div id="footer"><img src="{$app_path}images/bg_footer.gif" width="800" style="display:none;" onload="this.style.display='block'" border="0" alt="" /></div>
	<script type="text/javascript">
	if(document!=top.document){
		document.getElementById("header").style.display="none";
		document.getElementById("footer").style.display="none";
	}
	</script>
EOF;
	}
	echo "{$str}</div></body></html>";
}

/**
 * ��¼ÿ����Ƶ������ͳ����Ϣ
 * @param $id string ��Ƶ���
 * @param $finish bool �Ƿ񲥷����
 * ��¼���ܲ��Ŵ��������²��Ŵ��������²��Ŵ��������ղ��Ŵ��������ղ��Ŵ���
 */
function record_counter_v($id=null, $finish=false){
	$month = intval(date('Ym'));
	$date = intval(date('Ymd'));

	//�򿪲���ȡ
	$filename = PLAY_COUNTER_FILE;
	$exists = file_exists($filename);
	$handle = fopen_safe($filename, $counts);
	if($handle===false) return false;

	//�����ļ����ݣ��������Ͷ�ȡ����
	$isbad = false;
	$counts = unserialize(trim($counts));
	if(!is_array($counts)) {
		$isbad = $exists;
		if(file_exists($filename.'.bak')){
			//��ȡ�����ļ�
			$counts = file_get_contents($filename.'.bak');
			$counts = unserialize($counts);
		}
	}
	if(!is_array($counts)) {
		$counts=array('date'=>'19000101');
	}elseif(!isset($counts['date'])){
		$counts['date']='19000101';
	}

	//������ڱ��
	$last_date = $counts['date'];
	if($last_date!=$date){
		$last_month=intval(substr($last_date,0,6));
		foreach ($counts as $k=>&$v){
			if(!is_array($v)) continue;
			if($last_month!=$month){
				$v['lastm'] = $v['thism'];
				$v['thism'] = 0;
				$v['lastm_f'] = $v['thism_f'];
				$v['thism_f'] = 0;
			}
			$v['yestoday'] = $v['today'];
			$v['today'] = 0;
			$v['yestoday_f'] = $v['today_f'];
			$v['today_f'] = 0;
			unset($v);
		}
		unset($v);

		//����
		if($exists && !$isbad){
			copy($filename, $filename.'.bak');
		}
	}
	$counts['date'] = $date;

	if($id){
	    //��¼ĳ��Ӱ���Ĳ���ͳ��
		if(!empty($counts[$id])){
			$count=$counts[$id];
			if(!$finish){
			    $count['all']++;
			    $count['thism']++;
			    $count['today']++;
			}else{
        		$count['all_f']++;
        		$count['thism_f']++;
        		$count['today_f']++;
			}
		}else{
			$count=array(
    			'all'=>1,
    			'lastm'=>0,
    			'thism'=>1,
    			'yestoday'=>0,
    			'today'=>1,
			    'all_f'=>0,
			    'lastm_f'=>0,
			    'thism_f'=>0,
			    'yestoday_f'=>0,
			    'today_f'=>0,
    		);
		}
		$counts[$id]=$count;
	}

	//д��
	$ret = fwrite_safe($handle, $counts);

	//д��Զ��Ӱ��������
	global $remote_video_server, $config, $site_url, $app_path;
	if($ret && $remote_video_server){
	    $data = serialize(array('id'=>$id, 'finish'=>$finish?1:0, '_'=>time()));
	    $pwd = md5_16(DEFAULT_JYG_PASSWORD.$site_url.$app_path);
	    $data = juyuange_encrypt($data, $pwd);
	    http_post($remote_video_server, "v2={$data}", array('timeout'=>5, 'referer'=>$site_url.$app_path, 'proxy'=>$config['proxy']));
	}
	return $ret;
}

/**
 * �ж��Ƿ���ͨ���ֻ�����
 * @return bool �Ƿ����ƶ��豸
 */
function isMobile() {
    static $is_mobile=null;
    if($is_mobile===null) {
        $is_mobile=false;
        // �����HTTP_X_WAP_PROFILE��һ�����ƶ��豸
        if (isset($_SERVER['HTTP_X_WAP_PROFILE']) && $_SERVER['HTTP_X_WAP_PROFILE']) {
            $is_mobile=true;
        }
        //���via��Ϣ����wap��һ�����ƶ��豸,���ַ����̻����θ���Ϣ
        else if (isset($_SERVER['HTTP_VIA']) && stristr($_SERVER['HTTP_VIA'], "wap")!==false) {
            $is_mobile=true;
        }
        //�Բз����ж��ֻ����͵Ŀͻ��˱�־,�������д����
        else if (isset($_SERVER['HTTP_USER_AGENT'])) {
            $regex_match='/(ipad|nokia|iphone|android|motorola|^mot\-|softbank|foma|docomo|kddi|up\.browser|up\.link|'.
                'htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|'.
                'blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|'.
                'symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\-|longcos|pantech|gionee|^sie\-|portalmmm|'.
                'jig\s browser|hiptop|^ucweb|^benq|haier|^lct|opera\s*mobi|opera\*mini|320x320|240x320|176x220'.
                ')/i';
            if(preg_match($regex_match, $_SERVER['HTTP_USER_AGENT'])){
                $is_mobile=true;
            }
        }
        //Э�鷨����Ϊ�п��ܲ�׼ȷ���ŵ�����ж�
        else if(isset($_SERVER['HTTP_ACCEPT']) && ($s=strtolower($_SERVER['HTTP_ACCEPT']))) {
            // ���ֻ֧��wml���Ҳ�֧��html��һ�����ƶ��豸
            // ���֧��wml��html����wml��html֮ǰ�����ƶ��豸
            if (($x=strpos($s, 'vnd.wap.wml')) !== false && (($y=strpos($s, 'text/html')) === false || $x>$y)) {
                $is_mobile=true;
            }
        }
    }
    return $is_mobile;
}

/**��Ӱ����ַ����ȡӰ���б�
 * @param string $video
 */
function playlist_extract_list($video, $showError=true){
    if(strpos($video,"\n")>0){
        //�����б�
        $video = preg_replace('#[\n]{2,}#', "\n", $video);
        $arr = explode("\n", $video);
        foreach($arr as $k=>$v){
            if(empty($v)) {
                unset($arr[$k]);
                continue;
            }
            $line = $k+1;
            $arr2 = explode("|", $v);
            if(count($arr2)>2){
                if($showError) echo "Ӱ���ļ���ĵ� {$line} �и�ʽ����ֻ����һ�� | ����<br>";
                return false;
            }elseif(count($arr2)==1){
                $v_title = "��{$line}��";
                $v_video = $arr2[0];
            }else{
                $v_title = $arr2[0] ? $arr2[0] : "��{$line}��";
                $v_video = $arr2[1];
            }
            if(strpos($v_video, '.')===false){
                if($showError) echo "Ӱ���ļ���ĵ� {$line} �е���ַ({$v_video})����<br>";
                return false;
            }
            $arr[$k] = array($v_title, $v_video);
        }
        $videolist = $arr;
    }else if(preg_match('#^(.+?)(\.\w{2,4})\|(\d+)\|?$#', $video, $match)){
        $videolist = array();
        for($i=1; $i<=intval($match[3]); $i++){
            $videolist[$i] = array("��{$i}��", "{$match[1]}{$i}{$match[2]}");
        }
    }else{
        //����Ӱ��
        $videolist = array();
        if(strpos($video, '.')===false){
            if($showError) echo '������Ӱ���ļ���ַ<br>';
            return false;
        }else{
            $videolist[] = array('',$video);
        }
    }
    return $videolist;
}

