<?php
/**
 * �Ա���Ӱ���ļ��M�й����Ͳ���
 *
 * ��װ���÷�����
 * 1. ��վ�ռ�Ҫ֧�� php 5.0 �����ϰ汾
 * 2. ��վ�ռ�֧�� .htaccass �ļ������޸����е� RewriteBase ָ���֤��ߵ�·������ȷ��
 *
 * ʹ�ò��裺
 * 1. ��mediaĿ¼���ϴ���Ƶ(��֧��mp4)����Ƶ(��֧��mp3)
 * 2. ����ҳ���������ʺ�̨��ҳ forme.php����Ӱ���ļ����뵽�����б���
 * 3. �Ӻ�̨��õ����ŵ�ַ
 *
 */


require('inc.php');

//[�ӿ�]��������Ӱ���б�
if(empty($_GET) && isset($_POST['v1']) && count($_POST)==1){
    $data = $_POST['v1'];
    $pwd1 = md5_16(DEFAULT_JYG_PASSWORD.$_SERVER["HTTP_REFERER"]);
    $pwd2 = md5_16(DEFAULT_JYG_PASSWORD.$data.$_SERVER["HTTP_REFERER"]);
    $data = juyuange_decrypt($data, $pwd1);
    $data = unserialize($data);
    if(isset($data['md5'],$data['gz'],$data['_']) && abs(time()-$data['_'])<600){ //����ʱ�����ܳ���10����
        if($data['md5']==md5_file(LIST_FILE)){
            echo '304';
        }else{
            $gz = $data['gz'] && function_exists('gzencode');
            if($gz){
                $data = gzencode(file_get_contents(LIST_FILE),9);
            }else{
                $data = file_get_contents(LIST_FILE);
            }
            $data = str_encrypt($data);
            $data = $data ^ str_pad($pwd2,strlen($data),$pwd2);
            echo ($gz?'1':'0').$data;
        }
    }
    exit;
}

//[�ӿ�]�ϴ�����ͳ��
if(empty($_GET) && isset($_POST['v2']) && count($_POST)==1){
    $data = $_POST['v2'];
    $pwd = md5_16(DEFAULT_JYG_PASSWORD.$_SERVER["HTTP_REFERER"]);
    $data = unserialize(juyuange_decrypt($data, $pwd));
    if(isset($data['id'],$data['finish'],$data['_']) && abs(time()-$data['_'])<600){ //����ʱ�����ܳ���10����
        record_counter_v($data['id'], $data['finish']==1);
    }
    exit;
}


//��¼ͳ����Ϣ
if(!empty($_GET[COOKIE_VISIT])){
	if(!isset($_COOKIE[COOKIE_VISIT])){
		if(record_counter(VISIT_COUNTER_FILE)){
			//д��cookie�������ظ�����
			setcookie(COOKIE_VISIT, 1, strtotime("+1 week"), $app_path);
		}
	}
	header('Content-Type: image/png');
	exit;
}

//��������¼�
if(!empty($_GET['f'])){
    $ids = explode('_',$_COOKIE[COOKIE_FINISH]);
    if(!in_array($_GET['f'], $ids)){
        if(record_counter_v($_GET['f'],true)){
            //д��cookie�������ظ�����
            $ids[]=$_GET['f'];
            setcookie(COOKIE_FINISH, implode('_',$ids), strtotime("+1 week"), $app_path);
        }
    }
    header('Content-Type: image/png');
    exit;
}

//��ʼ������
$width = 600;
$height = 400;
$playitem = $id = null;

//���벥���б�
$playlist = unserialize(@file_get_contents(LIST_FILE));
if(empty($playlist)){
    exit('����Ӱ��');
}

//��������б�
if(!empty($_GET['l'])){
    $id = $_GET['l'];
    $playitem = $playlist[$id];
    if(empty($playitem) || empty($playitem['videolist'])){
    	header('HTTP/1.0 404 Not Found');
    	header('Content-Type: text/html');
    }else{
    	$imageUrl = $playitem['image'] ? get_thumb_url($playitem['image'],$playitem['proxy']) : "{$app_path}images/thumb_mp4.gif";
    	header('Content-Type: application/rss+xml');
        echo '<rss version="2.0" xmlns:jwplayer="http://rss.jwpcdn.com/"><channel>';
        foreach($playitem['videolist'] as $k=>$v){
            $v_title = mb_convert_encoding($v[0], 'html-entities', 'GBK');
            $v_video = get_real_url($v[1],$playitem['proxy']);
            echo "<item><title><![CDATA[{$v_title}]]></title><guid>{$id}-{$k}</guid><jwplayer:image>{$imageUrl}</jwplayer:image><jwplayer:source file=\"{$v_video}\" /></item>";
        }
        echo '</channel></rss>';
    }
    exit;
}

//��������url
$uri = $_SERVER['REQUEST_URI'];
if(preg_match('#/play/(\d+)\.html(\?|$)#', $uri, $match)){
    //��������ҳ
	$id = (int)$match[1];
}elseif(preg_match('#/miniplay/(\d+)-(\d+)-(\d+)\.html(\?|$)#', $uri, $match)){
    //���ҳ
	$id = (int)$match[1];
	$w = intval($match[2]);
	$h = intval($match[3]);
	if($w && $h){
		$width = $w;
		$height = $h;
	}else if($w && !$h){
		$height = $w/$width*$height;
		$width = $w;
	}else if(!$w && $h){
		$width = $h/$height*$width;
		$height = $h;
	}
	defined('IN_FRAME') or define('IN_FRAME', 1);
}

$query_keyword = '';
if($id){
    if(empty($playlist[$id]) || !$playlist[$id]['canplay']){
        echo defined('IN_FRAME') ? 'û�ҵ����Ӱ��' : '<script type="text/javascript">alert("û�ҵ����Ӱ��"); location.href="'.$app_path.'";</script>';
        exit;
    }
    $playitem = $playlist[$id];
    $keyword = $playitem['keyword'];
}elseif(!empty($_GET['k'])){
    include(INCLUDE_DIR.'/charset.inc.php');
    $query_keyword = trim($_GET['k']);
    if(Charset::isUtf8($query_keyword)) $query_keyword=mb_convert_encoding($query_keyword, 'gbk', 'utf-8');
    $keyword = array($query_keyword);
}elseif(!empty($_GET['k2'])){
    $query_keyword = urlsafe_base64_decode(trim($_GET['k2']));
    $keyword = array($query_keyword);
}

//�б�
$all_keywords = array();
$index = 0;
foreach($playlist as $k=>&$v){
	if($k==='lastid') continue;
    //$v['id'] = $k;
    if(!empty($v['keyword'])) $all_keywords = array_merge($all_keywords, $v['keyword']);
    $v['match'] = 0;
    if(!$v['canplay'] || !$v['show']) {
        unset($playlist[$k]);
        continue;
    }elseif(empty($keyword)){
        //
    }else{
        $arr = array_intersect($v['keyword'], $keyword);
        if(empty($arr)){
            unset($playlist[$k]);
            continue;
        }else{
            $v['match'] = count($arr);
        }
    }
    $v['match'] = (99-$v['match']) . str_pad(++$index, 6, '0', STR_PAD_LEFT);
    $v['class'] = $id==$k ? 'active' : '';
    unset($v);
}
$all_keywords = array_unique($all_keywords);

function sort_callback($a, $b){
    return strcmp($a['match'], $b['match']);
}
uasort($playlist, 'sort_callback');

//���
$played_ids = empty($_COOKIE[COOKIE_PLAY]) ? array() : explode('_',$_COOKIE[COOKIE_PLAY]);
head('',"<script type='text/javascript' src='{$app_path}../images/jwplayer.js'>
</script><script type='text/javascript' src='{$app_path}images/main.js'>
</script><script type='text/javascript' src='{$app_path}images/lazyload.js'></script>");
if($id && !empty($playitem)){
    if(!in_array($id, $played_ids)){
        if(record_counter_v($id,false)){
            //д��cookie�������ظ�����
            $played_ids[]=$id;
            setcookie(COOKIE_PLAY, implode('_',$played_ids), strtotime("+1 week"), $app_path);
        }
    }

    show_player();
    if(!defined('IN_FRAME')) show_list();
}else{
    show_list();
    refetch_video_list();
}
foot();

// ====================================================================================================

/**
 * �������������
 * @param string $title ��Ƶ����
 * @param string $videoUrl ��Ƶ�ļ���ʵ��ַ
 * @param string $downloadUrl ���ص�ַ
 */
function show_player(){
	global $playitem, $width, $height, $video_path, $thumb_path, $enable_bottom_nav, $app_path, $id, $site_name, $config;
	$is_mobile = isMobile() ? '1' : '0';
	$title = $playitem['title'];
	$title1 = str_encode("{$title} - {$site_name}");
	$title2 = str_encode($title);
	$videoUrl = !empty($playitem['videolist']) ? "{$app_path}?l={$id}" : get_real_url($playitem['video'],$playitem['proxy']);
	$fileext2 = preg_match('#\.(\w+)(\?|\r|\n|\|\d+\|?$|$)#', $playitem['video'], $match) ? $match[1] : 'mp4';
	$videoUrl = str_encode($videoUrl);
	$is_iframe = defined('IN_FRAME') ? 1 : 0;
	$is_audio = $fileext2=='mp3' ? 1 : 0;
	$hidden_iframe = defined('IN_FRAME') ? 'hidden' : '';
	$container_class = $is_audio ? 'v_is_audio' : 'v_is_video';
	$imageUrl = $playitem['image'] ? get_thumb_url($playitem['image'],$playitem['proxy']) : "{$app_path}images/thumb_{$fileext2}.gif";
	$imageUrl = str_encode($imageUrl);
	if(!defined('IN_FRAME')){
    	$desc = $playitem['desc'];
    	if(!preg_match('#(?:</div>|<br|<p\s|<p>|<table)#i', $desc)) $desc=str_replace('<br />', '<p />', nl2br($desc));
    	$desc = preg_replace('#\[(\d+)\|(\d+)\|(.+?)\]#', '<a href="javascript:" class="graybtn_s" onclick="play2(\\1,\\2);">\\3</a>', $desc);
    	$desc = str_encode($desc);
	}else{
	    $desc = '';
	}
	$autostart = defined('IN_FRAME') ? 'false' : 'true';
	$isVideolist = empty($playitem['videolist']) ? 'false' : 'true';

	if($config['player_only_allow_cn'] && !in_array(get_user_country(),array('CN','LOCAL'))){
		echo '<script type="text/javascript">var _u_cn_="N";</script>';
	}

	echo <<<EOF
<div id="v_title" class="{$hidden_iframe}"></div>
<div id="v_container" class="{$container_class}">
    <div id="v_play"></div>
    <div id="tips" class="{$hidden_iframe}">������Ų���������ͣ�󻺳�һ����ͺ��ˣ�<button onclick="closetips(this);">֪����</button></div>
</div>
<div id="v_desc" class="{$hidden_iframe}"></div>
<img id="img_onfinish" width="0" height="0" style="display:none" />
<script type='text/javascript'>
setTimeout(function(){G('tips').style.display='none';},5000);
function onfinish(){var img=G("img_onfinish"); if(!img.src) img.src="{$app_path}?f={$id}&_="+(+new Date());}
document.title=d('{$title1}');
var pageW={$is_mobile}?getDocWidth({$width}):{$width};
if(pageW>{$width}) pageW={$width};
pageW-=4;//ȥ���߿򳤶�
var pageH=Math.floor(pageW/{$width}*{$height});
G('v_container').style.width=pageW+'px';
if(!{$is_audio}) G('v_container').style.height=pageH+'px';
G('v_title').innerHTML=d('{$title2}');
G('v_desc').innerHTML=d('{$desc}');
if(document.cookie.indexOf('clst=1')!==-1 || {$is_audio}) V('tips');
play({$id},d('{$videoUrl}'),'{$fileext2}',d('{$imageUrl}'),d('{$title2}'),pageW,pageH,{$autostart},{$isVideolist},onfinish);
</script>
EOF;
}

/**
 * ���Ӱ���б�
 */
function show_list(){
    global $playlist, $id, $thumb_path, $enable_bottom_nav, $app_path, $site_name, $played_ids, $all_keywords, $query_keyword, $config;
    if(!empty($playlist)){
        //�ؼ����б�
        $all_keywords_html = '';
        foreach($all_keywords as $v){
            if($v) {
                $all_keywords_html .= $query_keyword==$v ? "<span>{$v}</span>" : "<a href='{$app_path}?k2=".urlsafe_base64_encode($v)."'>{$v}</a>";
            }
        }
        if($all_keywords_html) $all_keywords_html='<div class="keywords">'.$all_keywords_html.'</div>';

        $html = '<div id="playlist">'.$all_keywords_html.'<ul>';
        foreach($playlist as $k=>$v){
        	if($k=='lastid') continue;
            $v['class'] = $v['class'] ? $v['class'] : (in_array($k, $played_ids) ? 'played' : '');
            $fileext2 = preg_match('#\.(\w+)(\?|\r|\n|\|\d+\|?$|$)#', $v['video'], $match) ? $match[1] : 'mp4';
            $v['image'] = $v['image'] ? get_thumb_url($v['image'],$v['proxy']) : "{$app_path}images/thumb_{$fileext2}.gif";
            $playurl = "{$app_path}play/{$k}.html";
            $html .= "<li class='{$v['class']}'><a href=\"{$app_path}play/{$k}.html\" title=\"{$v['title']}\">".
                //"<img src=\"{$v['image']}\" alt=\"{$v['title']}\" />{$v['title']}</a></li>";
                "<img class='lazy' src=\"{$app_path}images/dot.gif\" data-original=\"{$v['image']}\" alt=\"{$v['title']}\" width='126' height='86' />{$v['title']}</a></li>";
        }
        $html .= '<div style="clear:both;"></div></ul><div style="clear:both;"></div></div>';
        $html = "<script type='text/javascript'>document.write(d('".str_encode($html)."'));</script>";
    }else{
        $html = '';
    }
    if(!$id){
        $title = str_encode($site_name);
        $html .= "<script type='text/javascript'>document.title=d('{$title}');</script>";
    }
    if(!isset($_COOKIE[COOKIE_VISIT])) $html .= '<img src="'.$app_path.'?'.COOKIE_VISIT.'=1" width="0" height="0" style="display:none" />';
    if($enable_bottom_nav) $html .= '<script type="text/javascript" src="/?' .$config['built_in_name'].'='.encrypt_builtin('nav'). '" charset="GBK"></script>';
    echo $html;
}

