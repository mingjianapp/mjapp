<?php
define('APP_CHARSET', 'GBK');
define('CACHE_EXPIRE', 3600); //������1Сʱ����Ч��
define('USERAGENT_PC', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)');
define('USERAGENT_MOBILE', 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Mobile');
define('DEFAULT_ANCHOR_PATTERN', '#<a [^>]*?\bhref\s*=\s*[\'"](?P<link>[^\'">]+)[\'"][^>]*>(?P<text>[^<>]+)</a>#');
define('DEFAULT_LIMIT', 15); //Ĭ�ϲɼ�����
define('NOW', time());
define('TEMPDIR', dirname(__FILE__).'/temp');

if(version_compare(PHP_VERSION, '5.3.3', '<')){
	exit('Need PHP 5.3.3 or higher!');
}

require('include/global.inc.php');
require('include/http.inc.php');

error_reporting(0);
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

$config = array(
	//��ҳ���⣨֧��html��ǩ��
	'title' => 'ÿ�վ�ѡ����',

	//�ɼ����������ӵ����������ø�ʽΪ http(s)://������Ҳ�����ǰ�Ƕ��ŷָ��Ķ��������Ϊ��ʱʹ�õ�ǰ������
	'servers' => '',

	//�������ı�����ɫ�������ɫ֮���ð�Ƕ��ŷָ�����������ɫ���ƣ�Ҳ���������� #CCCCCC ��������ɫֵ��
	'colors' => 'lightblue,lightgreen,orange,navy,purple,darkgreen,brown',

	//��վ���棨�����Ҫ���������������html��ҳ��ʽ�����е�{server}���ᱻ�滻Ϊ$servers���ֵ��
	'notice' => '',

	//��վ�ײ����ݣ�֧��html��ǩ��Ҳ����ʹ����������ģ�壩
	//<div><h2>����</h2><ul class="list"><li>��Ŀ</li></ul></div>
	//<div><h2>����</h2><div class="block text">����</div></div>
	'foot' => '',

	//���½��ǲ���֮��
	'proxy' => '',
);

$collect_configs = array(
	array(
		'title' => '��վ����',
		'url' => null,
		'text' => $config['notice'],
	),

	array(
		'title' => '���Ԫ �� ��½����',
		'url' => 'http://cn.epochtimes.com/gb/nsc413.htm',
		'start' => ' leading-news-list ',
		'end' => '</ul>',
		'pattern' => '#\bhref\s*=\s*[\'"](?P<link>[^">]+)[\'"][^>]*>(?P<text>.*?)</a>#s',
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '������ �� ��Ƶ����',
		'url' => 'http://cn.ntdtv.com/xtr/gb/prog204.html',
		'start' => '',
		'end' => '',
		'pattern' => '#<a .*?\bhref\s*=\s*[\'"](?P<link>[^">]+)[\'"][^>]*>(?P<text>[^<>]+?)<small class="vid"></small></a>#',
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '�������� �� �Ƽ�����',
		'url' => 'http://www.aboluowang.com/index.html',
		'start' => '#<div id="?tabbing1#',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '���й��� �� ���տ���',
		'url' => 'https://www.secretchina.com/',
		'start' => '#<div id="today">.*?<ul>|���տ��� ����\'>\s*����</a>#s',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => 'һ����������',
		'url' => 'http://wujieliulan.com/',
		'start' => 'id="tabpage_3">',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '����Ҫ��',
		'url' => 'http://wujieliulan.com/',
		'more' => 'http://www.minghui.org/',
		'start' => '<h2>����Ҫ��</h2>',
		'end' => '</ul>',
		'pattern' => DEFAULT_ANCHOR_PATTERN,
		'limit' => DEFAULT_LIMIT,
	),

	array(
		'title' => '��̬�� �� ��վָ��',
		'url' => 'http://dongtaiwang.com/loc/phome.php',
		'start' => '<div id="title">��̬����վָ��</div>',
		'end' => '<!-- end of center column -->',
		'pattern' => null,
		'header' => '<style type="text/css">#block_{index} .block{} #title_sub{padding:8px 0 1px 0px;font-weight:normal;color:#FF6600;} #ntdtv_player_info{display:none;}</style>',
	),
);

//һ���������
if(!empty($config['servers'])){
	$servers = explode(',', trim($config['servers'],','));
	$server = empty($servers) ? '' : $servers[array_rand($servers)];
	if($server){
		$server=trim($server,'/');
		if(strpos($server,'://')===false) $server='http://'.$server;
	}
}else{
	$server = Url::getCurrentUrl()->home;
}

//��ȡ����
$caches = array();
$cacheFile = TEMPDIR."/news.~tmp";
if(CACHE_EXPIRE>0 && file_exists($cacheFile)){
	$caches = unserialize(file_get_contents($cacheFile));
}
if(empty($caches) || !is_array($caches) || @$_GET['cache']=='0') {
	$caches = array();
}

//�������
$http_config = array('read_cache'=>false);
if(!empty($config['proxy'])) $http_config['proxy']=$config['proxy'];
$colors = explode(',', trim($config['colors'],','));

//�ӻ�����ߴ�Զ�̲ɼ�����
$requests = array();
$htmls = array();
$body = '';
$nav = array();
$index = -1;
$changed = false;
foreach($collect_configs as $k=>$v){
	if(empty($v['url']) && empty($v['text'])){
		unset($v[$k]);
	}
}
foreach($collect_configs as $v){
	$index++;
	$url = $v['url'];
	if($url) {
		$cacheKey = $url.'#'.$v['title'];
		$remoteUrl = Url::create($url);
		if(!$remoteUrl || !in_array($remoteUrl->scheme,array('http','https'))){
			continue;
		}
	}else{
		continue;
	}

	if(!empty($v['text'])){
		$block = "<div class=\"block text\">{$v['text']}</div>";
	}else if(isset($caches[$cacheKey]) && NOW-$caches[$cacheKey]['time']<CACHE_EXPIRE && $caches[$cacheKey]['hash']==hash('crc32',serialize($v))){
		$block = $caches[$cacheKey]['block'];
	}else{
		//���ز�����
		$block = '';
		if(isset($htmls[$url])){
			$html = $htmls[$url];
		}else{
			$start = microtime(true);
			$html = Http::getHtml($url, isset($v['useragent'])?$v['useragent']:USERAGENT_PC, APP_CHARSET, false, $http_config);
			$htmls[$url] = $html;
			$requests[$url] = microtime(true) - $start;
			if(stripos($html, '</a>')===false){
				$block = '<ul class="list"><li>'.$last_http_error.'</li></ul>';
			}
		}

		if(isset($v['collect'])){
			$rows = get_between_links($html, $v['start'], $v['end'], $v['collect'], $remoteUrl);
			if(is_array($rows)){
				$block .= '<ul class="list list-collect">';
				foreach($rows as $k=>$row){
					$s = str_replace($remoteUrl->home, '{server}', $row[0]);
					$s = str_replace('thread-new">', 'thread-new" target="_blank">', $s);
					$s = preg_replace('#\s+#s', ' ', $s);
					$block .= "<li>$s</li>\n";
				}
				$block .= '</ul>';
				$caches[$cacheKey] = array('time'=>NOW, 'block'=>$block, 'hash'=>hash('crc32',serialize($v)));
				$changed = true;
			}
		}else{
			$rows = get_between_links($html, $v['start'], $v['end'], $v['pattern'], $remoteUrl);
			if(is_string($rows)){
				$block .= "<div class=\"block\">{$rows}</div>";
				$caches[$cacheKey] = array('time'=>NOW, 'block'=>$block, 'hash'=>hash('crc32',serialize($v)));
				$changed = true;
			}else if(is_array($rows)){
				$block .= '<ul class="list list-pattern">';
				foreach($rows as $k=>$row){
					if($k>=$v['limit']) break;
					$text = trim(str_replace('&nbsp;','',strip_tags($row['text'],'<font><span>')));
					$block .= '<li><a href="' . encrypt_url($row['link'], $remoteUrl) . '" target="_blank">' . $text . '</a></li>';
				}
				$block .= '</ul>';
				$caches[$cacheKey] = array('time'=>NOW, 'block'=>$block, 'hash'=>hash('crc32',serialize($v)));
				$changed = true;
			}
		}

		if(!$block){
			$block = '<ul class="list"><li>��������</li></ul>';
		}
	}

	$more = !empty($v['more']) ? $v['more'] : $url;
	if(substr($more,0,1)!='{' || !$server) $more = encrypt_url($more);

	$body .=
		(!empty($v['header']) ? str_replace('{index}', $index, $v['header']) : '') .
		'<div id="block_'.$index.'"><h2 style="background-color:'.$colors[$index % count($colors)].'">'.
		($url ? "<a href='{$more}' target='_blank'>����&gt;&gt;</a>" : '').
		$v['title'] .
		'</h2>' . $block . '</div>';
}

$body = str_replace(array('��ͼ��','(ͼ)','(��ͼ)','(ͼ��)'), '<span class=tu>(ͼ)</span>', $body);

//д�뻺��
if(CACHE_EXPIRE>0 && $changed){
	file_put_contents($cacheFile, serialize($caches), LOCK_EX);
}

//�ײ�
if(!empty($config['foot'])){
	$foot = $config['foot'];
	while(strpos($foot,'<h2>')!==false){
		$index++;
		$foot = str_replace_once('<h2>', '<h2 style="background-color:'.$colors[$index % count($colors)].'">', $foot);
	}
	$body .= $foot;
}

//����
$nav = str_replace('{server}', $server, implode('',$nav));
$nav = str_encode_s($nav);
$body = str_replace('{server}', $server, $body);
$body = str_encode_s($body);
$css = css();
$title = str_encode_s($config['title']);
$plaintitle = strip_tags($title);

//���
header('Content-Type: text/html; charset='.APP_CHARSET);
// header('Cache-Control: public, max-age=86400');
// header('Last-Modified: '.gmtDate(TIME));
// header('Expires: '.gmtDate("+1 day"));
// header('ETag: '.substr(md5($body),8,16));

$charset = APP_CHARSET;
echo <<<EOF
<!DOCTYPE html><html><head><meta charset="{$charset}"><title>{$plaintitle}</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<script type="text/javascript">String.prototype.rot13=function(){return this.replace(/[a-zA-Z]/g,function(c){return String.fromCharCode((c<="Z"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26);});};
function d(s){if(!s)return '';var k=new RegExp('\\\\'+s.charAt(s.length-1),"g");s=s.substring(0,s.length-1);s=s.replace(k,'%');return decodeURIComponent(s.rot13());}
</script>
<!--link rel="stylesheet" type="text/css" href="style.css"/-->
<style type="text/css">$css</style>
</head><body>
<a name="top"></a>
<h1>{$title}</h1>
<!--ul class="nav">{$nav}<div class="clear"></div></ul><div class="clear"-->
<div class="sep"></div>
{$body}
<div class="gotop"><a href="#top">���ض���</a></div>
</body></html>
EOF;
exit;



/**
 * ��ȡ��ֹ���֮�������
 * @param string $content
 * @param string $start
 * @param string $end
 * @param string $pattern
 * @return array
 */
function get_between_links($content, $start, $end, $pattern, $remoteUrl){
	if(!$content || (!$start && !$end && !$pattern))
		return $content;

	//����ʼ����滻Ϊ�򵥵�ռλ��
	if(!empty($start)){
		if(($x=stripos($content,$start)) && ($x!==false)){
			$content = substr($content, $x+strlen($start));
		}else if($start{0}=='#' && preg_match($start, $content, $match, PREG_OFFSET_CAPTURE)){
			$content = substr($content, $match[0][1]+strlen($match[0][0]));
		}else{
			return false;
		}
	}

	//�ѽ�������滻Ϊ�򵥵�ռλ��
	if(!empty($end)){
		if(($x=stripos($content,$end)) && ($x!==false)){
			$content = substr($content, 0, $x-1);
		}else if($end{0}=='#' && preg_match($end, $content, $match, PREG_OFFSET_CAPTURE)){
			$content = substr($content, 0, $match[0][1]-1);
		}else{
			return false;
		}
	}

	//��ȡ$pattern
	if(!empty($pattern)){
		if(preg_match_all($pattern, $content, $matches, PREG_SET_ORDER)){
			return $matches;
		}
	}else{
		//ɾ���ű���ע��
		$content = preg_replace(array('#<!--.*?-->#s', '#<script[\s>].*?</script>#s', '#<object\s.*?</object>#s'), '', $content);
		//��������
		$links = array();
		if(preg_match_all(DEFAULT_ANCHOR_PATTERN, $content, $matches, PREG_SET_ORDER)){
			foreach($matches as $match){
				$links[] = $match['link'];
			}
		}
		if(!empty($links)){
			$links = array_unique($links);
			rsort($links);
			$search = $replace = array();
			foreach($links as $link){
				$search[] = $link;
				$replace[] = encrypt_url($link, $remoteUrl);
			}
			if(!empty($search)){
				$content = str_replace($search, $replace, $content);
			}
		}
		return $content;
	}
}

/**
 * ������ַ
 */
function encrypt_url($url, $remoteUrl=null){
	if(stripos($url,'http://')===false && stripos($url,'https://')===false && $remoteUrl){
		$url = $remoteUrl->getFullUrl($url, true);
	}

	if(strpos($url, 'http://cn.epochtimes.com/')===0){
		$url = preg_replace('#^(http://cn\.epochtimes\.com/(?:gb|b5)/)\w+\.htm\?p=\w+\#\w+-(\d+)-(\d+)-(\d+)-(\d+)$#', '$1$2/$3/$4/n$5.htm', $url);
	}

	if(strpos($url, 'http://www.secretchina.com/')===0){
		$url = preg_replace('#^(http://www\.secretchina\.com)/topic/\d+\.html\?nid=(\d+)&title=.*$#', '$1/node/$2', $url);
	}

	//����url
	return '{server}' . encrypt_url_2nd($url);
}

/**
 * ��ҳ���루����ǽ��
 */
function str_encode_s($str){
	$str = preg_replace('#\s+#s', ' ', $str);
	return mb_convert_encoding($str, 'html-entities', APP_CHARSET);
}

function css(){
return <<<EOF
*{margin:0; padding:0;}
html, body {height:100%;}
img{border:0; vertical-align:middle;}
a {color:#5f7b98;text-decoration:none}
a:hover {color:red;}
li{list-style-type:none;}
li a:visited {color:#5f7b99}
.clear{clear:both}

h1{color: #333;font-size:25px;height:40px;line-height:40px;text-align: center;background-image: linear-gradient(#ffffff, #f9f9f9);-webkit-box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.15);}
.nav{background-image: linear-gradient(#ffffff, #f9f9f9);-webkit-box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.15);border-bottom: 1px solid #D1D1D1; margin:5px;}
.nav li{width:100px; float:left; padding:10px 0; text-align:center;}
.nav li a{color: #666;}

.sep{height:20px;}
.title_video{display:inline-block;width:15px;min-height:15px;top:2px;position:relative;left:5px;
background:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPBAMAAADJ+Ih5AAAAA3NCSVQICAjb4U/gAAAAMFBMVEX/////VTL/////Tin/ORD/ZEX/qZf+8O3/clX+RiH+iXH+fWL7yb7+mob/2ND/PBS3VZBnAAAAEHRSTlMA////////////////////wFCLQwAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAAAAWdEVYdENyZWF0aW9uIFRpbWUAMDIvMTgvMTf26VP0AAAAf0lEQVQImWNgYCjbsfcBAxCoSRoKWxcwMDDtFJ0sKBzOwMA78dtLR0ErBobHgm7qLYbCBxguC7opqU0RXMDQCGQoVRg2MASCGEorAyAiaoIBYDV6IUA1h4GMKx+BurgN/6g6ClozMLAHS9gLCosD7aqQNBSUKADZeio06gADAwAiESEtFDulyQAAAABJRU5ErkJggg==") no-repeat left center;}
.tu{color:#f09; font-size:initial !important; margin-left:5px;}

h2 {font-size:20px;	padding:0 10px;	height:40px;line-height:40px;color:#fff; margin:5px; -webkit-box-shadow: 3px 3px 3px 0 #CCC;}
h2 a{float: right;font-size: 14px;color:#FFF; display:block; width:55px;}
.list {padding:0 10px; margin:5px;}
.list li {overflow:hidden; height:40px; line-height:40px; -webkit-box-sizing:border-box;border-bottom:1px #e2e4e8 dotted;background:transparent url('data:image/gif;base64,R0lGODlhDgAYAIAAAKqqqv///yH5BAEAAAEALAAAAAAOABgAAAIrDBCpa4e83IFRUiXfzTfx/m0WOIpO15zmRIWMW6kQjJWvHbMzXsu7LkIFCgA7') right center no-repeat;padding-right:20px;}
.list-pattern li a{display:block;padding-left:25px;background:transparent url('data:image/gif;base64,R0lGODlhDgAOAIABAMzMzP///yH5BAEAAAEALAAAAAAOAA4AAAIPDI55pu0Po5y02otzYzEUADs=') left 14px no-repeat;}

.block{padding:5px 10px;line-height:25px;}

.bg_brown{background:#ce4b27;}
.bg_navy{background:#5b3ab6;}
.bg_purple{background:#a300aa;}
.bg_darkgreen{background:#009600;}
.bg_highland{background:#0093a8;}
.bg_orange{background:#e88a05;}
.bg_lightblue{background:#3498db;}
.bg_lightgreen{background:#6db51c;}
.bg_red{background:#b51c44;}

.gotop{margin:10px 0;height:40px;line-height:40px;background: #b8c0c8;color: #fff;text-align: center;}
.gotop a{color: #fff;}
EOF;
}