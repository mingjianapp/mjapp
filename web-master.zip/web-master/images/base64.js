function base64_decode(tbl) {
    tbl = tbl || '';
    var chr = String.fromCharCode;
     
    if(!tbl){
    	for(var i=65;i<=90;i++) tbl+=chr(i);
    	tbl+=tbl.toLowerCase();
    	for(var i=48;i<=57;i++) tbl+=chr(i);
    	tbl+='+/';
    }
    var b64tab = function(bin) {
        var t = {};
        for (var i = 0, l = bin.length; i < l; i++) t[bin.charAt(i)] = i;
        return t;
    }(tbl);

    // decoder stuff
    var cb_decode = function(cccc) {
        var len = cccc.length,
        padlen = len % 4,
        n = (len > 0 ? b64tab[cccc.charAt(0)] << 18 : 0)
            | (len > 1 ? b64tab[cccc.charAt(1)] << 12 : 0)
            | (len > 2 ? b64tab[cccc.charAt(2)] <<  6 : 0)
            | (len > 3 ? b64tab[cccc.charAt(3)]       : 0),
        chars = [
            chr( n >>> 16),
            chr((n >>>  8) & 0xff),
            chr( n         & 0xff)
        ];
        chars.length -= [0, 0, 2, 1][padlen];
        return chars.join('');
    };
    var atob = function(a){return a.replace(/[\s\S]{1,4}/g, cb_decode);};
    var decode = function(a) { return btou(atob(a)) };
    
    /*rand*/
    
    var re_btou = new RegExp([
        '[\xC0-\xDF][\x80-\xBF]',
        '[\xE0-\xEF][\x80-\xBF]{2}',
        '[\xF0-\xF7][\x80-\xBF]{3}'
    ].join('|'), 'g');
    cb_btou = function(cccc) {
        switch(cccc.length) {
        case 4:
            var cp = ((0x07 & cccc.charCodeAt(0)) << 18)
                |    ((0x3f & cccc.charCodeAt(1)) << 12)
                |    ((0x3f & cccc.charCodeAt(2)) <<  6)
                |     (0x3f & cccc.charCodeAt(3)),
            offset = cp - 0x10000;
            return (chr((offset  >>> 10) + 0xD800)
                    + chr((offset & 0x3FF) + 0xDC00));
        case 3:
            return chr(
                ((0x0f & cccc.charCodeAt(0)) << 12)
                    | ((0x3f & cccc.charCodeAt(1)) << 6)
                    |  (0x3f & cccc.charCodeAt(2))
            );
        default:
            return  chr(
                ((0x1f & cccc.charCodeAt(0)) << 6)
                    |  (0x3f & cccc.charCodeAt(1))
            );
        }
    },
    btou = function(b) {return b.replace(re_btou, cb_btou);};
    
    // export
    return {
        d: decode,
        btou: btou
    };
}('');
