var bEditChanged=false;
function G(id){
	return document.getElementById(id);	
}
function editChanged(){
	bEditChanged=true;
}
function ignoreChanged(){
	if(!bEditChanged || confirm('�������༭��������')){
		return true;
	}else{
		return false;
	}
}
function del(id){
	if(!ignoreChanged()) return false;
	if(confirm('ȷʵҪɾ����')){
		G('formOther_form_action').value='del';
		G('formOther_id').value=id;
		G('formOther').submit();
	}
}
function moveup(id,moveto){
	if(!ignoreChanged()) return false;
	G('formOther_form_action').value='moveup';
	G('formOther_moveto').value=moveto;
	G('formOther_id').value=id;
	G('formOther').submit();
}
function checkForm(f){
	var v='';
	v=G(f+'_title').value; if(!v){alert('���������'); return false;}
	v=G(f+'_external').value; if(v && v.indexOf('//')===-1 && v.indexOf('/')!==0){alert('����ȷ����վ������'); return false;}
	//if(!G(f+'_answer').value){alert('������ش�����'); return false;}
	return true;
}

function StartRoll(id) {
  var scrollspeed=20;
  var scrollwidth=1;  
	var myTimer;
	var divMain=G(id);
	var divContainer=G(id+'_container');
	var divContainer1=G(id+'_container_1');
  var divContainer2=G(id+'_container_2');

  var Rolling=function(){
  	if(divMain.scrollLeft>=divContainer1.offsetWidth) divMain.scrollLeft=0;
  	divMain.scrollLeft+=scrollwidth;
  };

	var doRoll=function(){
		myTimer=setInterval(function(){Rolling();}, scrollspeed);
	};

	if (divMain && divContainer && divContainer1 && divContainer2) {
	  divContainer2.innerHTML=divContainer1.innerHTML;
		doRoll();
		divMain.onmouseover=function(){clearInterval(myTimer)};
		divMain.onmouseout=function(){doRoll();};
	}
}

String.prototype.rot13 = function(){
	return this.replace(/[a-zA-Z]/g, function(c){
		return String.fromCharCode((c <= "Z" ? 90 : 122) >= (c = c.charCodeAt(0) + 13) ? c : c - 26);
	});
};

function encryptI(e,i){
	var enc=function(s){
		//var seed=97+Math.floor(Math.random()*26);
		return '_'+encodeURIComponent(s.replace(/_/g,'%5F')).replace(/%/g,'_').replace(/[a-zA-Z]/g, function(c){
			return String.fromCharCode((c <= "Z" ? 90 : 122) >= (c=c.charCodeAt(0)+13) ? c : c-26);
		});
	};	
	G(i).value=enc(e.value);
}

var activeTab=1;
function changeTab(id){
  G('tab_'+activeTab).className='';
  G('tab_'+id).className='active';
  G('tab_content_'+activeTab).style.display='none';
  G('tab_content_'+id).style.display='block';
  activeTab=id;
}

function resizeIframe(id) {
	var pTar = null;
	if (G) {
		pTar = G(id);
	} else {
		eval('pTar = ' + id + ';');
	}
	if (pTar && !window.opera) {
		//begin resizing iframe 
		pTar.style.display = "block";
		if (pTar.contentDocument && pTar.contentDocument.body.offsetHeight) {
			//ns6 syntax 
			pTar.height = pTar.contentDocument.body.offsetHeight + 20;
			pTar.width = pTar.contentDocument.body.scrollWidth + 20;
		} else if (pTar.Document && pTar.Document.body.scrollHeight) {
			//ie5+ syntax 
			pTar.height = pTar.Document.body.scrollHeight;
			pTar.width = pTar.Document.body.scrollWidth;
		}
//		pTar.style.height = pTar.height+'px';
//		pTar.style.width = pTar.width+'px';
	}
}

function setFilter(){
	var items=[G('filter_0'),G('filter_1'),G('filter_2')];
	var re=/(^|\s)filter=(\d*)/, arr=re.exec(document.cookie), c=arr?arr[2]:'0123';
	for(var i=0; i<=2; i++){
		items[i].checked = c.indexOf(i)!=-1;
	}
}
function changeFilter(){
	var items=[G('filter_0'),G('filter_1'),G('filter_2')];
	var c='';
	for(var i=0; i<=2; i++){
		if(items[i].checked) c+=i.toString();
	}
	document.cookie='filter='+c;
	if(ignoreChanged()) location.reload();
}
