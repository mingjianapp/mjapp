function hex_md5(b) {
	var hexcase = 0;
	var b64pad = "";
	var chrsz = 8;
	return binl2hex(core_md5(str2binl(b), b.length * chrsz));
	function core_md5(a, q) {
		a[q >> 5] |= 128 << ((q) % 32);
		a[(((q + 64) >>> 9) << 4) + 14] = q;
		var b = 1732584193;
		var c = -271733879;
		var d = -1732584194;
		var i = 271733878;
		for (var t = 0; t < a.length; t += 16) {
			var r = b;
			var s = c;
			var u = d;
			var v = i;
			b = md5_ff(b, c, d, i, a[t + 0], 7, -680876936);
			i = md5_ff(i, b, c, d, a[t + 1], 12, -389564586);
			d = md5_ff(d, i, b, c, a[t + 2], 17, 606105819);
			c = md5_ff(c, d, i, b, a[t + 3], 22, -1044525330);
			b = md5_ff(b, c, d, i, a[t + 4], 7, -176418897);
			i = md5_ff(i, b, c, d, a[t + 5], 12, 1200080426);
			d = md5_ff(d, i, b, c, a[t + 6], 17, -1473231341);
			c = md5_ff(c, d, i, b, a[t + 7], 22, -45705983);
			b = md5_ff(b, c, d, i, a[t + 8], 7, 1770035416);
			i = md5_ff(i, b, c, d, a[t + 9], 12, -1958414417);
			d = md5_ff(d, i, b, c, a[t + 10], 17, -42063);
			c = md5_ff(c, d, i, b, a[t + 11], 22, -1990404162);
			b = md5_ff(b, c, d, i, a[t + 12], 7, 1804603682);
			i = md5_ff(i, b, c, d, a[t + 13], 12, -40341101);
			d = md5_ff(d, i, b, c, a[t + 14], 17, -1502002290);
			c = md5_ff(c, d, i, b, a[t + 15], 22, 1236535329);
			b = md5_gg(b, c, d, i, a[t + 1], 5, -165796510);
			i = md5_gg(i, b, c, d, a[t + 6], 9, -1069501632);
			d = md5_gg(d, i, b, c, a[t + 11], 14, 643717713);
			c = md5_gg(c, d, i, b, a[t + 0], 20, -373897302);
			b = md5_gg(b, c, d, i, a[t + 5], 5, -701558691);
			i = md5_gg(i, b, c, d, a[t + 10], 9, 38016083);
			d = md5_gg(d, i, b, c, a[t + 15], 14, -660478335);
			c = md5_gg(c, d, i, b, a[t + 4], 20, -405537848);
			b = md5_gg(b, c, d, i, a[t + 9], 5, 568446438);
			i = md5_gg(i, b, c, d, a[t + 14], 9, -1019803690);
			d = md5_gg(d, i, b, c, a[t + 3], 14, -187363961);
			c = md5_gg(c, d, i, b, a[t + 8], 20, 1163531501);
			b = md5_gg(b, c, d, i, a[t + 13], 5, -1444681467);
			i = md5_gg(i, b, c, d, a[t + 2], 9, -51403784);
			d = md5_gg(d, i, b, c, a[t + 7], 14, 1735328473);
			c = md5_gg(c, d, i, b, a[t + 12], 20, -1926607734);
			b = md5_hh(b, c, d, i, a[t + 5], 4, -378558);
			i = md5_hh(i, b, c, d, a[t + 8], 11, -2022574463);
			d = md5_hh(d, i, b, c, a[t + 11], 16, 1839030562);
			c = md5_hh(c, d, i, b, a[t + 14], 23, -35309556);
			b = md5_hh(b, c, d, i, a[t + 1], 4, -1530992060);
			i = md5_hh(i, b, c, d, a[t + 4], 11, 1272893353);
			d = md5_hh(d, i, b, c, a[t + 7], 16, -155497632);
			c = md5_hh(c, d, i, b, a[t + 10], 23, -1094730640);
			b = md5_hh(b, c, d, i, a[t + 13], 4, 681279174);
			i = md5_hh(i, b, c, d, a[t + 0], 11, -358537222);
			d = md5_hh(d, i, b, c, a[t + 3], 16, -722521979);
			c = md5_hh(c, d, i, b, a[t + 6], 23, 76029189);
			b = md5_hh(b, c, d, i, a[t + 9], 4, -640364487);
			i = md5_hh(i, b, c, d, a[t + 12], 11, -421815835);
			d = md5_hh(d, i, b, c, a[t + 15], 16, 530742520);
			c = md5_hh(c, d, i, b, a[t + 2], 23, -995338651);
			b = md5_ii(b, c, d, i, a[t + 0], 6, -198630844);
			i = md5_ii(i, b, c, d, a[t + 7], 10, 1126891415);
			d = md5_ii(d, i, b, c, a[t + 14], 15, -1416354905);
			c = md5_ii(c, d, i, b, a[t + 5], 21, -57434055);
			b = md5_ii(b, c, d, i, a[t + 12], 6, 1700485571);
			i = md5_ii(i, b, c, d, a[t + 3], 10, -1894986606);
			d = md5_ii(d, i, b, c, a[t + 10], 15, -1051523);
			c = md5_ii(c, d, i, b, a[t + 1], 21, -2054922799);
			b = md5_ii(b, c, d, i, a[t + 8], 6, 1873313359);
			i = md5_ii(i, b, c, d, a[t + 15], 10, -30611744);
			d = md5_ii(d, i, b, c, a[t + 6], 15, -1560198380);
			c = md5_ii(c, d, i, b, a[t + 13], 21, 1309151649);
			b = md5_ii(b, c, d, i, a[t + 4], 6, -145523070);
			i = md5_ii(i, b, c, d, a[t + 11], 10, -1120210379);
			d = md5_ii(d, i, b, c, a[t + 2], 15, 718787259);
			c = md5_ii(c, d, i, b, a[t + 9], 21, -343485551);
			b = safe_add(b, r);
			c = safe_add(c, s);
			d = safe_add(d, u);
			i = safe_add(i, v)
		}
		return Array(b, c, d, i)
	}
	function md5_cmn(a, j, k, l, b, i) {
		return safe_add(bit_rol(safe_add(safe_add(j, a), safe_add(l, i)), b), k)
	}
	function md5_ff(l, m, a, b, n, c, d) {
		return md5_cmn((m & a) | ((~m) & b), l, m, n, c, d)
	}
	function md5_gg(l, m, a, b, n, c, d) {
		return md5_cmn((m & b) | (a & (~b)), l, m, n, c, d)
	}
	function md5_hh(l, m, a, b, n, c, d) {
		return md5_cmn(m ^ a ^ b, l, m, n, c, d)
	}
	function md5_ii(l, m, a, b, n, c, d) {
		return md5_cmn(a ^ (m | (~b)), l, m, n, c, d)
	}
	function core_hmac_md5(n, k) {
		var l = str2binl(n);
		if (l.length > 16) {
			l = core_md5(l, n.length * chrsz)
		}
		var i = Array(16),
			m = Array(16);
		for (var h = 0; h < 16; h++) {
			i[h] = l[h] ^ 909522486;
			m[h] = l[h] ^ 1549556828
		}
		var j = core_md5(i.concat(str2binl(k)), 512 + k.length * chrsz);
		return core_md5(m.concat(j), 512 + 128)
	}
	function safe_add(f, g) {
		var h = (f & 65535) + (g & 65535);
		var e = (f >> 16) + (g >> 16) + (h >> 16);
		return (e << 16) | (h & 65535)
	}
	function bit_rol(d, c) {
		return (d << c) | (d >>> (32 - c))
	}
	function str2binl(g) {
		var h = Array();
		var f = (1 << chrsz) - 1;
		for (var e = 0; e < g.length * chrsz; e += chrsz) {
			h[e >> 5] |= (g.charCodeAt(e / chrsz) & f) << (e % 32)
		}
		return h
	}
	function binl2hex(h) {
		var e = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
		var g = "";
		for (var f = 0; f < h.length * 4; f++) {
			g += e.charAt((h[f >> 2] >> ((f % 4) * 8 + 4)) & 15) + e.charAt((h[f >> 2] >> ((f % 4) * 8)) & 15)
		}
		return g
	}
}