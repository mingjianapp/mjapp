<?php
/**
 * ��Ҫ��ʾ�ĵ����������M���ټӹ�
 * @param string $html
 * @return string
 */
function my_show_navigation_js($html){
	if(preg_match('#//begin_tj\s+(.+?)\s+//end_tj#', $html, $match)){
	    $block = trim($match[1]); exit('block  =' . $block);
		$news = '';
		if(preg_match_all('#<li>��<a href=[\'"]([^<>\'"]+?)[\'"][^<>]+>([^<>\'"]+?)</a></li>#', $block, $matches, PREG_SET_ORDER)){
			for($i = 0, $count_i = count($matches); $i < $count_i; ++ $i) {
				$news .= "['{$matches[$i][1]}','{$matches[$i][2]}'],\n";
			}
		}
		$html = str_replace($block, $news, $html);
	}
	return $html;
}
