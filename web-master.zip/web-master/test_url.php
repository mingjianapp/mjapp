<?php
require('common.inc.php');
require(APPDIR.'/config.inc.php');
require(APPDIR.'/include/func.inc.php');
require(APPDIR.'/include/http.inc.php');
require(APPDIR.'/include/coding.inc.php');
require(APPDIR.'/include/db.inc.php');

header('Content-Type: text/html; charset=GBK');

$encrypt_seed = '';
if(!empty($_POST['encrypt_seed'])){
	$config['encrypt_seed'] = $encrypt_seed = $_POST['encrypt_seed'];
}
$oldurl = '';
if(!empty($_POST['oldurl'])){
	$oldurl = $_POST['oldurl'];
	if(strpos($oldurl,'://')===false) {
		$oldurl = Url::getCurrentUrl()->getFullUrl($oldurl,true);
	}
	$currentUrl = Url::create($oldurl);

	$_SERVER['REQUEST_METHOD'] = 'GET';
	$_SERVER['REQUEST_SCHEME'] = $currentUrl->scheme;
	$_SERVER['HTTP_HOST'] = $currentUrl->site;
	$_SERVER['SERVER_NAME'] = $currentUrl->host;
	$_SERVER['SERVER_PORT'] = $currentUrl->port;
	$_SERVER['REQUEST_URI'] = $currentUrl->uri;
	$_SERVER['QUERY_STRING'] = $currentUrl->query;
	$_SERVER['HTTP_REFERER'] = '';
	$currentUrl->path = '/';
	$currentUrl->script = '/index.php';
	$currentUrl->file = 'index.php';
	$currentUrl->original = $oldurl;
	parse_str($_SERVER['QUERY_STRING'], $_GET);
	$_GET['__nonematch__'] = 1;
}else{
	$currentUrl = Url::getCurrentUrl();
}

init_config();
$urlCoding = new UrlCoding($currentUrl);

//���ⱻ����
if(!empty($_POST)){
	$uid = md5($_SERVER['SERVER_NAME'].get_ip());
	$uidStatFile = TEMPDIR."/{$uid[0]}/{$uid}.~tmp";
	$lastTime = file_exists($uidStatFile) ? filemtime($uidStatFile) : 0;
	$passedSec = time()-$lastTime;
	if($passedSec<2){
		$_GET = $_POST;
		unset($_POST);
	}else{
		if(!@touch($uidStatFile)){
			mkdir(dirname($uidStatFile));
			touch($uidStatFile);
		}
	}
}

if($oldurl){
	$encrypt_site_old = encode_parts_old($oldurl); if($encrypt_site_old==$oldurl) $encrypt_site_old='�����ܱ�����';
	$encrypt_site_new = encode_parts_new($oldurl); if($encrypt_site_new==$oldurl) $encrypt_site_new='�����ܱ�����';
	$encrypt_site_rand = encrypt_url_2nd($oldurl); if($encrypt_site_rand==$oldurl) $encrypt_site_rand='�����ܱ�����';
	$encrypt = encodeUrl($oldurl); if($encrypt==$oldurl) $encrypt='�����ܱ�����';
	$decrypt = decodeUrl($oldurl);
}else{
	$encrypt = $decrypt = $encrypt_site_old = $encrypt_site_new = $encrypt_site_rand = '';
	$oldurl = isset($_GET['oldurl']) ? $_GET['oldurl'] : '';
}
echo <<<EOF
<form method="post" action="">
	�������ӣ�<input type="text" name="encrypt_seed" value="{$encrypt_seed}" size="80" /><br/>
	������ַ��<input type="text" name="oldurl" value="{$oldurl}" size="80" onMouseOver="this.select()" /> <a href="{$oldurl}" target="_blank">����</a><br/>
	���ܽ����<input type="text" name="encrypt" value="{$encrypt}" size="80" /> <a href="{$encrypt}" target="_blank">����</a><br/>
	���ܽ����<input type="text" name="decrypt" value="{$decrypt}" size="80" /> <a href="{$decrypt}" target="_blank">����</a><br/>
	����������(�ɰ棬����ǰ�������¶���ͬ)��<a href="{$encrypt_site_old}" target="_blank">{$encrypt_site_old}</a><br/>
	����������(�°棬�ڸ�ǰ�������¶���ͬ)��<a href="{$encrypt_site_new}" target="_blank">{$encrypt_site_new}</a><br/>
	�������(�°棬�ڸ�ǰ�������¶��ܽ���)��<a href="{$encrypt_site_rand}" target="_blank">{$encrypt_site_rand}</a><br/>
	<br/>
	<input type="submit" value="���ܻ����url" />
</form>
EOF;

echo "\r\n\r\n<!--\r\n";
echo "client_id = " . @file_get_contents(DATADIR.'/~sync_client_id.dat') . "\r\n";
echo "encrypt_seed = {$config['encrypt_seed']}\r\n";
echo "SERVER_NAME = {$_SERVER['SERVER_NAME']}\r\n";
echo "key = {$config['key']}\r\n";
echo "siteid = {$config['siteid']}\r\n";
echo "encrypt_keys = {$config['encrypt_keys'][0]} {$config['encrypt_keys'][1]}\r\n";
echo "encrypt2_key = {$config['encrypt2_key']}\r\n";
echo "encrypt2_key = " . crc32u('qwwqr.dgsdgsdgfrt.cf') . "\r\n";
echo '-->';

exit;




function encodeUrl($url){
	global $config, $urlCoding;

	//����վ�㹦��
	if(!empty($config['mirror_site'])){
		require_once(APPDIR."/include/mirror.inc.php");
	}

	//�����Զ�����
	if(isset($config['plugin']) && $config['plugin'] && file_exists(APPDIR."/plugin/{$config['plugin']}.php")){
		require_once(APPDIR."/plugin/{$config['plugin']}.php");
	}

	$ret = $urlCoding->encodeUrl($url, null, null, true);
	if(!$ret) {
		return '����ʧ��';
	}else{
		return $ret;
	}
}

function decodeUrl($url){
	global $config, $urlCoding;

	//�����Զ�����
	if(isset($config['plugin']) && $config['plugin'] && file_exists(APPDIR."/plugin/{$config['plugin']}.php")){
		require_once(APPDIR."/plugin/{$config['plugin']}.php");
	}

	//����վ�㹦��
	if(!empty($config['mirror_site'])){
		require_once(APPDIR."/include/mirror.inc.php");
	}

	$remoteUrl = $urlCoding->getRemoteUrl($url);
	if(!$remoteUrl) {
		return '����ʧ��';
	}else{
		return $remoteUrl->url;
	}
}

/**
 * ��������������
 */
function encode_parts_old($url){
	if(preg_match('#^(https?)://([\w\-\.]+)(:\d+)?(/.*)?$#', $url, $match)){
		if(!isset($match[3])) $match[3]='';

		$domain = $match[2];
		$port =  substr($match[3],1);
		$uri = isset($match[4]) ? $match[4] : '';
		$host = $port && $port!='80' && $port!='443' && strpos($domain,'/')===false ? "$domain:$port" : $domain;
		$isHTTPS = $match[1] == 'https';

		global $currentUrl, $urlCoding;
		if($urlCoding->isBlockDomain($domain)){
			return "/blank/";
		}elseif($urlCoding->isSafeDomain($domain) || $urlCoding->isSafeDomain("{$match[2]}{$match[3]}")){
			return $url;
		}
		$ret = strtr($host,':','@');
		$ret = "/_site_".strlen($ret).'_'.($isHTTPS===true||$isHTTPS==='https'||$isHTTPS==='https:'?'1':'0').'_'.str_rot13($ret);
		return $ret . $uri;
	}else{
		return $url;
	}
}
function encode_parts_new($url){
	if(preg_match('#^(https?)://([\w\-\.]+)(:\d+)?(/.*)?$#', $url, $match)){
		$host = $match[2] . (isset($match[3]) ? $match[3] : '');
		$uri = isset($match[4]) ? $match[4] : '';
		$isHTTPS = $match[1] == 'https';

		global $config, $currentUrl, $urlCoding;
		if($urlCoding->isSafeDomain($host)){
			return $url;
		}elseif($urlCoding->isBlockDomain($host)){
			return '/blank/';
		}else{
			$ret = $urlCoding->encodeString($host);
			$len = BASE62_TABLE[strlen($ret) % 62];
			$checksum = crc32c($config['siteid'].$ret);
			$ret =  "{$checksum}{$len}{$ret}";
			$ret = '/h' . ($isHTTPS?'1':'0') . '/' . $ret;
			return $ret . $uri;
		}
	}else{
		return $url;
	}
}
function encode_parts_coding($host, $isHTTPS){
	global $urlCoding;
	$s1 = $urlCoding->encodeParts($host, $isHTTPS);
	$s2 = decodeUrl(str_replace('{app_site}','',$s1));
	echo "���ܺ�{$s1}�����ܺ�{$s2}<br>";
}
