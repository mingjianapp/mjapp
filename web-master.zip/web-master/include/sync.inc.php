<?php
define('DOMAIN_MAX_DAYS', 7);
define('SHOW_DEBUG_INFO', 0);
define('SYNC_CLIENT_ID_FILE', DATADIR.'/~sync_client_id.dat');
define('SYNC_MARK_FILE', TEMPDIR.'/~sync_mark.~tmp');

$all_download_files = array('address.dat','ats.dat','faq.dat','video.dat','white_domains.dat');
$all_upload_files = array('~counter_visit.dat', '~counter_visit_faq.dat', '~counter_visit_video.dat', '~counter_visit_address.dat', '~counter_3tui.dat'); // '~counter_play_video.dat');

//����
if(DEBUGING>1) {
    if(file_exists(SYNC_MARK_FILE)) unlink(SYNC_MARK_FILE);
}

//����������ķ�����������()
$error = false;
if(empty($config['sync_server'])){
    $error = true;
}elseif(SHOW_DEBUG_INFO<2){
    if(strpos($config['sync_server'],'/'.Url::getCurrentSite().'/')!==false){
        $error = true;
    }
}
if($error){
    echo '//error';
    exit;
}

//��ʼͬ��
$mtime = file_exists(SYNC_MARK_FILE) ? filemtime(SYNC_MARK_FILE) : 0;
if(time()-$mtime>600 || DEBUGING!=0){ //ÿ10���ӳ���һ��
    //���ü������־�ļ����������̹߳�Ƶ�����M��
    touch(SYNC_MARK_FILE);
    //�����û��жϺͳ�ʱ
    @ignore_user_abort(true);
    //��Ϊ�����������첽���󣬲��Һܿ�ͻ��ڿͻ��˱�ȡ����������Ҫ��ʱˢ�»�������������ÿ�
    echo str_repeat(' ', 1024);
    ob_flush();
    flush();
    //��ȡ�ϴ�ͬ���ļ�¼
    $sync_record = file_get_contents_safe(SYNC_MARK_FILE);
    $sync_record = $sync_record ? unserialize($sync_record) : array('download'=>0, 'upload'=>0);
    //���������ķ�����֮��ͬ������
    sync_client_download();
    sync_client_upload();
}
exit;


/**
 * ��ȡ�ֻ�������
 * @param string $client_id
 * @param string $client_name
 */
function get_client_info($client_id, $client_name=''){
    static $client_table = null;
    if($client_table===null){
        if(file_exists(SYNC_CLIENT_ID_FILE)){
            $client_table = unserialize(file_get_contents_safe(SYNC_CLIENT_ID_FILE));
        }else{
           $client_table = array();
        }
    }
    $ret = isset($client_table[$client_id]) ? $client_table[$client_id] : $client_id;
    if($client_name){
        $ret .= "({$client_name})";
    }
    return $ret;
}

/**
 * Ϊ�ֻ�����
 * @param string $client_id
 * @param string $client_name
 */
function set_client_info($client_id, $client_name){
    if(!empty($client_id) && !empty($client_name)){
        if(file_exists(SYNC_CLIENT_ID_FILE)){
            $client_table = unserialize(file_get_contents_safe(SYNC_CLIENT_ID_FILE));
        }else{
           $client_table = array();
        }
        $client_table[$client_id] = $client_name;
        file_put_contents(SYNC_CLIENT_ID_FILE, serialize($client_table), LOCK_EX);
    }
    echo '<script type="text/javascript">parent.location.reload();</script>';
    exit;
}


//=====================================================================================
//================ client =============================================================
//=====================================================================================


/**
 * Ϊÿ������������һ��ΨһID���־û���/data/~id.dat�ļ���
 */
function get_client_id(){
    static $id = null;
    if($id){
        return $id;
    }
    if(file_exists(SYNC_CLIENT_ID_FILE)){
        $id = trim(file_get_contents(SYNC_CLIENT_ID_FILE));
    }
    if(!$id || strlen($id)!=16){
        $id = substr(md5(uniqid(serialize($_SERVER),true)),8,16);
        file_put_contents(SYNC_CLIENT_ID_FILE, $id, LOCK_EX);
    }
    return $id;
}

function updateMarkContent($type){
    global $sync_record;
    $sync_record[$type] = time();
    file_put_contents(SYNC_MARK_FILE, serialize($sync_record), LOCK_EX);
}

/**
 * ÿ�ո���һ��data�ļ�
 */
function sync_client_download(){
    //������������
    global $all_download_files, $sync_record;
    if(date('d',$sync_record['download']) == date('d')) {
        echo '//1';
        return false;
    }

    //׼��Ҫ�ύ�����ݣ��ļ��������ʱ����б���
    $fileContents = array();
    foreach($all_download_files as $filename){
        $fullfile = DATADIR.'/'.$filename;
        if(file_exists($fullfile)){
            $fileContents[$filename]=md5_file($fullfile);
        }
    }

    //�ϴ�
    $response = post_encrypted_data('download',$fileContents);
    if($response == 'ok'){
        updateMarkContent('download');
        if(SHOW_DEBUG_INFO) echo '//OK';
        return true;
    }elseif($response=='304'){
        //û�仯
        if(SHOW_DEBUG_INFO) echo '//304';
        return false;
    }elseif($response==''){
        //������������10���Ӻ�����
        if(SHOW_DEBUG_INFO) echo '//err 101';
        return false;
    }elseif(substr($response,0,5)=='[err]'){
        if(SHOW_DEBUG_INFO) echo '//err ' . $response;
        return false;
    }elseif($response[0]!='1' && $response[0]!='1'){
        if(SHOW_DEBUG_INFO) echo '//err 102';
        return false;
    }else{
        //������Ӧ����
        $clientHome = Url::getCurrentScheme().'://'.Url::getCurrentSite();
        $pwd = md5_16(DEFAULT_JYG_PASSWORD.$clientHome);
        $data = decrypt_data($response, $pwd);
        if(!is_array($data)) {
            if(SHOW_DEBUG_INFO) echo '//err 103';
            return false;
        }

        //���±����ļ�
        $updatedFilenames = array();
        foreach($data as $filename=>$content){
            if(in_array($filename, $all_download_files)){
                $fullfile = DATADIR.'/'.$filename;
                file_put_contents($fullfile, $content, LOCK_EX);
                $updatedFilenames[] = $filename;
            }
        }

        updateMarkContent('download');
        if(SHOW_DEBUG_INFO) echo "//updated " . implode(', ', $updatedFilenames);
        return true;
    }
}

/**
 * ÿ1Сʱ�ϴ�һ�η���ͳ�ƣ����ͳ����Ϣû���������ٱ�֤ÿ���ϴ�һ��
 */
function sync_client_upload(){
    //������������
    global $all_upload_files, $sync_record;

    if(time()-$sync_record['upload']<3600) {
        echo '//1';
        return false;
    }

    get_address_counter();

    //׼��Ҫ�ύ�����ݣ��ļ��������ݵ��б���
    $now = time();
    $fileContents = array();
    foreach($all_upload_files as $filename){
        $fullname = DATADIR.'/'.$filename;
        if(!file_exists($fullname)) continue;
        $mtime = filemtime($fullname);
        if($mtime<=$sync_record['upload']){
            if(date('d',$mtime)!=date('d')){
                touch($fullname);
            }else{
                continue;
            }
        }

        $content = file_get_contents_safe($fullname);
        if($content) {
            //���˵�����һ������������ͳ��
            $changed = false;
            $arr = unserialize($content);
            if(isset($arr['domains'])){
                foreach($arr['domains'] as $k=>$v){
                    if($now-$v[5]>86400*DOMAIN_MAX_DAYS){
                        unset($arr['domains'][$k]);
                        $changed = true;
                    }
                }
                if($changed){
                    $content = serialize($arr);
                }
            }
            //Ҫ�ϴ������ݣ����Ҫ���ϴ������M�й��ˣ����ڴ˴���
            $fileContents[$filename] = $content;
        }
    }
    if(empty($fileContents)){
        updateMarkContent('upload');
        if(SHOW_DEBUG_INFO) echo '//nothing for up';
        return false;
    }

    //�ϴ�
    $response = post_encrypted_data('upload',$fileContents);
    if($response == 'ok'){
        updateMarkContent('upload');
        echo '//ok';
        return true;
    }elseif(substr($response,0,5)=='[err]'){
        if(SHOW_DEBUG_INFO) echo '//err ' . $response;
    }else{
        if(SHOW_DEBUG_INFO) echo '//err 201';
    }
    //������������10���Ӻ�����
    return false;
}

/**
 * �ϴ��ӿ�����
 */
function post_encrypted_data($api, $content){
    global $config;

    $clientHome = Url::getCurrentScheme().'://'.Url::getCurrentSite();
    $pwd = md5_16(DEFAULT_JYG_PASSWORD.$clientHome);
    $data = array(
        'gz'=>function_exists('gzencode') && function_exists('gzdecode'),
        'client_name'=>$_SERVER['SERVER_NAME'],
        'client_id'=>get_client_id(),
        'api'=>$api,
        'content'=>$content,
        '_'=>time(),
    );
    $data = encrypt_data($data, $pwd);

    $option = array('timeout'=>60, 'referer'=>$clientHome, 'proxy'=>$config['proxy']);
    if(DEBUGING>1) $option['cookie'] = $_COOKIE;

    $server = $config['sync_server'];
    if(substr($server,-1,1)!='/'){
        $server .= '/';
    }
    return http_post("{$server}sync.php?page=server", "data={$data}", $option);
}


//=====================================================================================
//================ ���� =============================================================
//=====================================================================================


/**
 * �����ɿͻ�����������ݻ��߷��������ص�����
 */
function encrypt_data($data, $pwd, $gz=null){
    $ret = serialize($data);
    $ret = (($gz!==null && $gz) || (isset($data['gz']) && $data['gz'])) ? ('1'.gzencode($ret,9)) : ('0'.$ret);
    $ret = $ret ^ str_pad($pwd,strlen($ret),$pwd);
    $ret = str_encrypt($ret);
    return $ret;
}

function decrypt_data($data, $pwd){
    $data = str_decrypt($data);
    $data = $data ^ str_pad($pwd,strlen($data),$pwd);
    $gz = $data[0]=='1';
    $data = substr($data, 1);
    if($gz) $data = gzdecode($data);
    $data = unserialize($data);
    return $data;
}
