<?php
/**
 * ͬʱ֧��MySQL+SQLite+PDO��PHP���ݿ���
 */
class Db {
	var $adapter = "";
	var $method = "";
	var $version = "";
	var $conn = false;
	var $errorMessage = "";
	var $db = "";

	//��sqlite3ʹ��
	var $resultID = null;
	var $resultData = null;

	/**
	 * �������ݿ�
	 * ����sqlite���ݿ⣺new Db('sqlite', '�ļ���');
	 * ����mysql���ݿ⣺new Db('mysql', 'localhost/���ݿ���', '�û���', '����');
	 * @param string $adapter
	 * @param string $database
	 * @param string $user=''
	 * @param string $pass=''
	 */
	function __construct($adapter, $database, $user='', $pass=''){
		$this->adapter=strtolower(trim($adapter));
		switch($this->adapter){
			case 'mysql':
				$this->connectMysql($database, $user, $pass);
				break;
			case 'sqlite':
				$this->connectSqlite($database);
				break;
			default:
				$this->errorMessage = 'Adapter not supported.';
				return;
		}
	}
	function Db($adapter, $database, $user='', $pass='') {
		$this->__construct($adapter, $database, $user, $pass);
	}

	function __destruct(){
		$this->disconnect();
	}

	/**
	 * ��ȡ�����ַ�����sql����ʽ
	 * @param string $field
	 * @param string $str
	 * @return string
	 */
	public function concat($field, $str){
		if($this->adapter=='sqlite'){
			return $field.'||\''.$str.'\'';
		}else{
			return 'concat('.$field.',\''.$str.'\')';
		}
	}

	/**
	 * ����mysql���ݿ�
	 * @param string $database
	 * @param string $user
	 * @param string $pass
	 */
	private function connectMysql($database, $user='', $pass=''){
		$this->method = "mysql";
		list($host,$db) = explode('/', $database, 2);
		if($host && $db){
			$this->conn = @mysql_connect($host, $user, $pass);
			if($this->conn) {
				if(mysql_select_db($db)){
					$this->db = $db;
					$this->query("SET NAMES 'utf8'");
				}else{
					$this->conn=false;
					$this->errorMessage ='Can\'t use '.$db.' : ' . mysql_error();
				}
			}else{
				$this->conn=false;
				$this->errorMessage = 'Not connected.';
			}
		}else{
			$this->conn=false;
			$this->errorMessage = 'Params error.';
		}
	}

	/**
	 * ����SQLite���ݿ�
	 * @param string $database
	 */
	private function connectSqlite($database){
		$pdoEnabled=class_exists("PDO");
		if ($pdoEnabled && in_array("sqlite", PDO::getAvailableDrivers())) {
			$this->method = "pdo";
			$this->version = 3;
			try {
				$this->conn = new PDO("sqlite:" . $database, null, null, array(PDO::ATTR_PERSISTENT => true));
			} catch(PDOException $error) {
				$this->conn = false;
				$this->errorMessage = $error->getMessage();
			}
		} else if ($pdoEnabled && in_array("sqlite2", PDO::getAvailableDrivers())) {
			$this->method = "pdo";
			$this->version = 2;
			try {
				$this->conn = new PDO("sqlite2:" . $database, null, null, array(PDO::ATTR_PERSISTENT => true));
			} catch(PDOException $error) {
				$this->conn = false;
				$this->errorMessage = $error->getMessage();
			}
		} else if (function_exists('sqlite_libversion') && function_exists('sqlite_open')) {
			$this->method = "sqlite";
			$this->version = sqlite_libversion();
			$this->conn = sqlite_open($database, 0666, $sqliteError);
		} else if (class_exists('SQLite3')) {
			if($this->resultID) $this->resultID->finalize();
			$this->resultData = null;

			$this->method = "sqlite3";
			$this->version = 3;
			$this->conn = new SQLite3($database);
		} else {
			$this->conn=false;
			$this->errorMessage = 'Db disabled error.';
		}

		if ($this->conn) {
			if ($this->method == "pdo") {
				$this->conn->setAttribute(PDO::ATTR_ERRMODE, defined('DEBUGING') && DEBUGING ? PDO::ERRMODE_WARNING : PDO::ERRMODE_SILENT);
			}
			$this->db = $database;
		}
	}

	public function connected() {
		return ($this->conn !== false);
	}

	public function disconnect() {
		if ($this->conn) {
			if ($this->method == "pdo") {
				//
			} else if ($this->method == "mysql") {
				mysql_close($this->conn);
			} else if ($this->method == "sqlite") {
				sqlite_close($this->conn);
			} else if ($this->method == "sqlite3") {
				if($this->resultID) $this->resultID->finalize();
				$this->resultData = null;
				$this->conn->close();
			}
		}
		$this->conn = null;
	}

	/**
	 * ִ�����ݿ��ѯ
	 * @param string $sql
	 * @return mixed ��ѯ�����ʾ��������false
	 */
	function query($sql) {
		if ($this->conn) {
			if ($this->method == "pdo") {
				$queryResult = $this->conn->prepare($sql);
				if ($queryResult) {
					if(!$queryResult->execute()){
						$errorInfo = $queryResult->errorInfo();
						$this->errorMessage = $errorInfo[2];
						return false;
					}
				} else {
					$errorInfo = $this->conn->errorInfo();
					$this->errorMessage = $errorInfo[2];
				}
				return $queryResult;
			} else if ($this->method == "mysql") {
				$queryResult = mysql_query($sql, $this->conn);
				if (!$queryResult) {
					$this->errorMessage = mysql_error();
				}
				return $queryResult;
			} else if ($this->method == "sqlite") {
				$queryResult = sqlite_query($this->conn, $sql);
				if (!$queryResult) {
					$this->errorMessage = sqlite_error_string(sqlite_last_error($this->conn));
				}
				return $queryResult;
			} else if ($this->method == "sqlite3") {
				$isSelect = stripos(trim($sql), 'select ')===0;
				$queryResult = $isSelect ? $this->conn->query($sql) : $this->conn->exec($sql);
				if (!$queryResult) {
					$this->errorMessage = $this->conn->lastErrorCode() . ' ' . $this->conn->lastErrorMsg();
				}
				if($isSelect && is_resource($queryResult))
				$this->resultID = $queryResult;
				$this->resultData = null;
				return $queryResult;
			}

		} else {
			return false;
		}
	}

	/**
	 * ��ȡ��һ����¼
	 */
	public function getOne($sql){
		$result = $this->query($sql);
		if($result){
			return $this->fetchAssoc($result);
		}else{
			return false;
		}
	}

	// Be careful using this function - when used with pdo, the pointer is moved
	// to the end of the result set and the query needs to be rerun. Unless you
	// actually need a count of the rows, use the isResultSet() function instead
	// ���� pdo �� sqlite3 ����Ҫ�����������������֪����������Ӱ�����ܣ������ʹ�ã���ʹ�� isResultSet()
	function rowCount($resultSet) {
		if (! $resultSet)
			return false;

		if ($this->conn) {
			if ($this->method == "pdo") {
				return count($resultSet->fetchAll());
			} else if ($this->method == "mysql") {
				return mysql_num_rows($resultSet);
			} else if ($this->method == "sqlite") {
				return sqlite_num_rows($resultSet);
			} else if ($this->method == "sqlite3") {
				$ret=$this->sqlite3_fetch_all($resultSet);
				return empty($ret) ? 0 : count($ret);
			}
		}
	}

	function isResultSet($resultSet) {
		if ($this->conn) {
			if ($this->method == "pdo") {
				return ($resultSet == true);
			} else if ($this->method == "sqlite3") {
				return ($resultSet && $resultSet !== true);
			} else {
				return ($this->rowCount($resultSet) > 0);
			}
		}
	}

	function fetchArray($resultSet) {
		if (! $resultSet)
			return false;

		if ($this->conn) {
			if ($this->method == "pdo") {
				return $resultSet->fetch(PDO::FETCH_NUM);
			} else if ($this->method == "mysql") {
				return mysql_fetch_row($resultSet);
			} else if ($this->method == "sqlite") {
				return sqlite_fetch_array($resultSet, SQLITE_NUM);
			} else if ($this->method == "sqlite3") {
				return $resultSet->fetchArray(SQLITE3_NUM);
			}

		}
	}

	function fetchAssoc($resultSet) {
		if (! $resultSet)
			return false;

		if ($this->conn) {
			if ($this->method == "pdo") {
				return $resultSet->fetch(PDO::FETCH_ASSOC);
			} else if ($this->method == "mysql") {
				return mysql_fetch_assoc($resultSet);
			} else if ($this->method == "sqlite") {
				return sqlite_fetch_array($resultSet, SQLITE_ASSOC);
			} else if ($this->method == "sqlite3") {
				return $resultSet->fetchArray(SQLITE3_ASSOC);
			}
		}
	}

	function affectedRows($resultSet) {
		if (! $resultSet)
			return false;

		if ($this->conn) {
			if ($this->method == "pdo") {
				return $resultSet->rowCount();
			} else if ($this->method == "mysql") {
				return mysql_affected_rows($resultSet);
			} else if ($this->method == "sqlite") {
				return sqlite_changes($resultSet);
			} else if ($this->method == "sqlite3") {
				return $resultSet->changes();
			}
		}
	}

	function sqlite3_fetch_all($resultSet){
		if($resultSet && !$this->resultData){
			$rows = array();
			while (($row = $resultSet->fetchArray(SQLITE3_BOTH))!=false) {
				$rows[] = $row;
			}
			$this->resultData = $rows;
			$resultSet->reset();
		}
		return $this->resultData;
	}

	function result($resultSet, $targetRow, $targetColumn = "") {
		if (! $resultSet)
			return false;

		if ($this->conn) {
			if ($this->method == "pdo") {
				if ($targetColumn) {
					$resultRow = $resultSet->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_ABS, $targetRow);
					return $resultRow[$targetColumn];
				} else {
					$resultRow = $resultSet->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_ABS, $targetRow);
					return $resultRow[0];
				}
			} else if ($this->method == "mysql") {
				return mysql_result($resultSet, $targetRow, $targetColumn);
			} else if ($this->method == "sqlite") {
				return sqlite_column($resultSet, $targetColumn);
			} else if ($this->method == "sqlite3") {
				$targetColumn = intval($targetColumn);
				$rows = $this->sqlite3_fetch_all($resultSet);
				if(!$rows || !isset($rows[$targetRow], $rows[$targetRow][$targetColumn])){
					return false;
				}else{
					return $rows[$targetRow][$targetColumn];
				}
			}
		}
	}

	function listTables() {
		if ($this->conn) {
			if ($this->adapter == "mysql") {
				return $this->query("SHOW TABLES");
			} else if ($this->adapter == "sqlite") {
				return $this->query("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name");
			}
		}
	}

	function insertId() {
		if ($this->conn) {
			if ($this->method == "pdo") {
				return $this->conn->lastInsertId ();
			} else if ($this->method == "mysql") {
				return mysql_insert_id($this->conn);
			} else if ($this->method == "sqlite") {
				return sqlite_last_insert_rowid($this->conn);
			} else if ($this->method == "sqlite3") {
				return $this->conn->lastInsertRowID();
			}
		}
	}

	function escapeString($toEscape) {
		if ($this->conn) {
			if ($this->method == "pdo") {
				$toEscape = $this->conn->quote($toEscape);
				$toEscape = substr($toEscape, 1, - 1);
				return $toEscape;
			} else if ($this->method == "mysql") {
				return mysql_real_escape_string($toEscape);
			} else if ($this->method == "sqlite") {
				return sqlite_escape_string($toEscape);
			} else if ($this->method == "sqlite3") {
				return $this->conn->escapeString($toEscape);
			}
		}
	}

	function getVersion() {
		if ($this->conn) {
			// cache
			if ($this->version) {
				return $this->version;
			}

			if ($this->adapter == "mysql") {
				$verSql = mysql_get_server_info ();
				$version = explode("-", $verSql);
				$this->version = $version[0];
			} else if ($this->method == "sqlite") {
				$this->version = sqlite_libversion();
			} else if ($this->method == "sqlite3") {
				$version = $this->conn->version();
				$this->version = $version['versionString'];
			}
			return $this->version;
		}
	}

	// returns the number of rows in a table
	function tableRowCount($table) {
		if ($this->conn) {
			if ($this->adapter == "mysql") {
				$countSql = $this->query("SELECT COUNT(*) AS `RowCount` FROM `" . $table . "`");
				$count = (int) ($this->result($countSql, 0, "RowCount" ));
				return $count;
			} else if ($this->adapter == "sqlite") {
				$countSql = $this->query("SELECT COUNT(*) AS 'RowCount' FROM '" . $table . "'");
				$count = (int) ($this->result($countSql, 0, "RowCount" ));
				return $count;
			}
		}
	}

	// gets column info for a table
	function describeTable($table) {
		if ($this->conn) {
			if ($this->adapter == "mysql") {
				return $this->query("DESCRIBE `" . $table . "`");
			} else if ($this->adapter == "sqlite") {
				$columnSql = $this->query("SELECT sql FROM sqlite_master where tbl_name = '" . $table . "'");
				$columnInfo = $this->result($columnSql, 0, "sql");
				$columnStart = strpos($columnInfo, '(');
				$columns = substr($columnInfo, $columnStart + 1, - 1);
				$columns = preg_split('#,[^0-9]#', $columns);

				$columnList = array ();

				foreach($columns as $column) {
					$column = trim($column);
					$columnSplit = explode(" ", $column, 2);
					$columnName = $columnSplit[0];
					$columnType = (sizeof($columnSplit ) > 1) ? $columnSplit[1] : "";
					$columnList[] = array (
							$columnName,
							$columnType
					);
				}

				return $columnList;
			}
		}
	}

	function error() {
		return $this->errorMessage;
	}
}