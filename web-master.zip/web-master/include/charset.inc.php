<?php
/**
 * �ַ�������ת��������ʹ�� iconv �� mbstring����ϵͳ��֧��ʱ��ʹ�ö��ձ������ַ���ת��
 */

if(!function_exists('hex2bin')){
	/**
	 * �� 16 ����ת��Ϊ 2 �����ַ�
	 * @param string $hexdata Ϊ16���Ƶı���
	 * @return �ַ���
	 */
	function hex2bin($hexdata) {
		$bindata = '';
		for($i = 0, $count = strlen ( $hexdata ); $i < $count; $i += 2) {
			$bindata .= chr( hexdec($hexdata{$i} . $hexdata{$i+1}) );
		}
		return $bindata;
	}
}

class Charset {
	const BLANK_CHAR = '&#9633;';	//������ձ���ȫ��û�������ַ�����ʾΪ�հ׷���
	private $iconvEnabled = false; // �Ƿ���� ICONV ģ�飬Ĭ��Ϊ��
	private $mbstringEnabled = false; // �Ƿ���� MBSTRING ģ�飬Ĭ��Ϊ��
	/**
	 * ��������
	 */
	private $config = array (
		'codetable_dir' => '', // ��Ÿ������Ի�������Ŀ¼
		'from_encoding' => '', // �ַ���ԭ����
		'to_encoding' => '', // ת����ı���
		'GB2UNI_table' => 'gbk_unicode.txt', // GBK��������ת��ΪUNICODE�Ķ��ձ�
		'BIG52UNI_table' => 'big5_unicode.txt', // BIG5��������ת��ΪUNICODE�Ķ��ձ�
	);
	/**
	 * �ȴ�ת�����ַ���
	 */
	private $sourceText = '';
	/**
	 * ���ת�����ձ�������
	 */
	private $unicodeTable = array ();

	function __construct() {
		$this->iconvEnabled = function_exists ('iconv');
		$this->mbstringEnabled = extension_loaded('mbstring') && function_exists('mb_convert_encoding');
		$this->config['codetable_dir'] = dirname (__FILE__) . '/codetable/';
	}
	function Charset(){
		$this->__construct();
	}

	/**
	 * �жϱ����ǲ���utf-8 (Ϊ��Ч�ʣ����жϳ�ascii�ַ�֮���ǰ100��utf8�������)
	 */
	static public function isUtf8($str) {
		//׼�����ձ�
		static $tables = array(
			'inited' => false,
			//'ascii' => array(0x09, 0x0A, 0x0D),
			'c2df' => array(),
			'80bf' => array(),
			'a0bf' => array(),
			'straight' => array(0xEE, 0xEF),
			'809f' => array(),
			'90bf' => array(),
			'f1f3' => array(0xF1, 0xF2, 0xF3),
			'808f' => array(),
		);
		if($tables['inited']==false){
			//for($i=0x20; $i<=0x7E; $i++) $tables['ascii'][]=$i;
			for($i=0xC2; $i<=0xDF; $i++) $tables['c2df'][]=$i;
			for($i=0x80; $i<=0xBF; $i++) $tables['80bf'][]=$i;
			for($i=0xA0; $i<=0xBF; $i++) $tables['a0bf'][]=$i;
			for($i=0xE1; $i<=0xEC; $i++) $tables['straight'][]=$i;
			for($i=0x80; $i<=0x9F; $i++) $tables['809f'][]=$i;
			for($i=0x90; $i<=0xBF; $i++) $tables['90bf'][]=$i;
			for($i=0x80; $i<=0x8F; $i++) $tables['808f'][]=$i;
			$tables['inited']=true;
		}

		//ȥ��ascii������ַ��ж�
		$str=preg_replace('#[\x09\x0A\x0D\x20-\x7E]+#x', '', $str);
		$len=strlen($str);
		$str.='    '; //��Ϊ�˱������
		$word=$i=0;
		while($i<$len && $i<1000){
			$c1=ord($str{$i});
			$c2=ord($str{$i+1});

// 			if(in_array($c1,$tables['ascii'])){
// 				$i++;
// 			}else

			if(in_array($c1,$tables['c2df']) && in_array($c2,$tables['80bf'])){
				$i+=2;
			}else{
				$c3=ord($str{$i+2});
				if($c1==0xE0 && in_array($c2,$tables['a0bf']) && in_array($c3,$tables['80bf'])){
					$i+=3;
				}else if(in_array($c1,$tables['straight']) && in_array($c2,$tables['80bf']) && in_array($c3,$tables['80bf'])){
					$i+=3;
				}else if($c1==0xED && in_array($c2,$tables['809f']) && in_array($c3,$tables['80bf'])){
					$i+=3;
				}else{
					$c4=ord($str{$i+3});
					if($c1==0xF0 && in_array($c2,$tables['90bf']) && in_array($c3,$tables['80bf']) && in_array($c4,$tables['80bf'])){
						$i+=4;
					}else if(in_array($c1,$tables['f1f3']) && in_array($c2,$tables['80bf']) && in_array($c3,$tables['80bf']) && in_array($c4,$tables['80bf'])){
						$i+=4;
					}else if($c1==0xF4 && in_array($c2,$tables['808f']) && in_array($c3,$tables['80bf']) && in_array($c4,$tables['80bf'])){
						$i+=4;
					}else{
						return false;
					}
				}
			}

			if($word++>100) break;
		}
		return true;

		//�����ú����жϣ�׼ȷ�ȿ��ܲ����ϱߺ�����
		// 		try{
		// 			if(function_exists('iconv')){
		// 				return iconv('UCS-2', 'UTF-8', iconv('UTF-8', 'UCS-2', $str))==$str;
		// 			}else if(function_exists('mb_convert_encoding')){
		// 				return mb_convert_encoding(mb_convert_encoding($str, 'UCS-2', 'UTF-8'), 'UTF-8', 'UCS-2');
		// 			}
		// 		}catch (Exception $e) {
		// 			return false;
		// 		}
	}

	//�Ƿ���utf8���������
	//$include_symbol �������Ƿ�����ı����Ϊ������
	public function isHanzi_Utf8($str, $include_symbol=true){
		if($include_symbol==true){
			//�������ı��
			return preg_match('/^(?:[\xc0-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3})+$/', $str);
		}else{
			//���������ı�㣨���б��ʱ����false��
			return preg_match("/^[\x{4e00}-\x{9fa5}]+$/u",$str);
		}
	}

	//�Ƿ���Big5���������(�������ı��)
	public function isHanzi_Big5($str){
		return preg_match('/^(?:[\x81-\xfe](?:[\x40-\x7e]|[\xa1-\xfe]))+$/', $str);
	}

	//�Ƿ���GBK���������(�������ı��)
	public function isHanzi_GBK($str){
		return preg_match('/^(?:[\x81-\xfe][\x40-\xfe])+$/', $str);
	}

	/**
	 * ��ʼ����ת��������֧�֣�
	 * GBK<=>UTF-8, BIG-5<=>UTF-8,
	 * GBK=>UNICODE, BIG-5=>UNICODE,
	 * UNICODE<=>UTF-8,
	 * UTF-8=>html-entities�� UNICODE=>html-entities
	 *
	 * @param string $str Ҫת�����ַ���
	 * @param string $to_encoding Ŀ�����
	 * @param string $from_encoding ԭ����
	 * @return ���ر������ַ���
	 */
	public function convert($str, $to_encoding, $from_encoding) {
		/* ����ַ���Ϊ�ջ����ַ�����û�к��ֲ���Ҫת����ֱ�ӷ��� */
		if ($str == '' || preg_match ( "/[\x80-\xFF]+/", $str ) == 0) {
			return $str;
		}

		//��������mbstringʱ���ȿ��Ǽ��ݶ�charset������
		if ($this->mbstringEnabled && strpos($to_encoding,',')!==false) {
			$ret=@mb_convert_encoding($str, $to_encoding, $from_encoding);
			if($ret)
				return $ret;
		}

		if ($from_encoding) {
			$from_encoding = $this->getLang($from_encoding);
			$this->config['from_encoding'] = $from_encoding;
		}
		if ($to_encoding) {
			$to_encoding = $this->getLang($to_encoding);
			$this->config['to_encoding'] = $to_encoding;
		}
		/* ���������ͬ��ֱ�ӷ��� */
		if ($this->config['from_encoding'] == $this->config['to_encoding']) {
			return $str;
		}

		//����ʹ�����ú���ת��
// 		if ($this->iconvEnabled || $this->mbstringEnabled) {
// 			$string = $this->convertIconvMbstring ($str, $to_encoding, $from_encoding);
// 			if ($string)
// 				return $string;
// 		}

		//ʹ�ö��ձ�ʵ��ת��
		$this->OpenTable ();
		$this->sourceText = $str;
		// �ж��Ƿ�ΪGBK��big5������UTF8ת��
		if (
			 (($from_encoding == 'GBK' || $from_encoding == 'BIG-5') && $to_encoding == 'UTF-8') ||
			 ($from_encoding == 'UTF-8' && ($to_encoding == 'GBK' || $to_encoding == 'BIG-5'))
			 ) {
			return $this->CHStoUTF8();
		}
		// �ж��Ƿ�ΪGBK��big5������UNICODE��html-entitiesת��
		else if (($from_encoding == 'GBK' || $from_encoding == 'BIG-5') && ($to_encoding == 'UNICODE' || $to_encoding == 'html-entities')) {
			return $this->CHStoUNICODE();
		}
		// utf8 -> unicode
		else if (($from_encoding == 'UTF-8') && $to_encoding == 'UNICODE') {
			return $this->utf8ToUnicode();
		}
		// unicode -> utf8
		else if (($from_encoding == 'UNICODE') && $to_encoding == 'UTF-8') {
			return $this->unicodeToUtf8();
		}
		// utf8 -> html-entities
		else if (($from_encoding == 'UTF-8') && $to_encoding == 'html-entities') {
			return $this->utf8ToHtmlentities();
		}
		// unicode -> html-entities
		else if (($from_encoding == 'UNICODE') && $to_encoding == 'html-entities') {
			return $this->unicodeToHtmlentities();
		}
	}

	/**
	 * ��ʽ����������
	 * @param string $lang
	 * @return string
	 */
	private function getLang($lang) {
		$lang = strtoupper ( $lang );
		if(stripos($lang,'entities')!==false){
			return 'html-entities';
		}
		if (substr ( $lang, 0, 2 ) == 'GB') {
			return 'GBK';
		} else {
			switch (substr ( $lang, 0, 3 )) {
				case 'BIG' : return 'BIG-5';
				case 'UTF' : return 'UTF-8';
				case 'UNI' : return 'UNICODE';
				case 'UCS' : return 'UNICODE';
				default : return '';
			}
		}
	}

	/**
	 * ʹ��PHP���ú���ʵ��ת��
	 * @param string $string Ҫת�����ı�
	 * @param string $from_encoding ԭʼ����
	 * @param string $to_encoding Ŀ�����
	 */
	private function convertIconvMbstring($str, $to_encoding, $from_encoding) {
		if ($this->iconvEnabled && $to_encoding!=='html-entities') {
			$ret = @iconv($from_encoding, $to_encoding, $str);
			if ($ret !== false) {
				return $ret;
			}
		}

		if ($this->mbstringEnabled) {
			if($from_encoding == 'GBK') $from_encoding = 'CP936';
			if($to_encoding == 'GBK') $to_encoding = 'CP936';
			if($from_encoding=='UNICODE') $from_encoding=='UCS-2';
			if($to_encoding=='UNICODE') $to_encoding=='UCS-2';
			if($from_encoding==$to_encoding) return $str;
			return @mb_convert_encoding($str, $to_encoding, $from_encoding);
		}
	}

	/**
	 * �򿪶��ձ�
	 */
	private function OpenTable() {
		static $gbk_unicode_table = NULL;
		static $big5_unicode_table = NULL;

		// ����ԭ����ΪGBK�������ĵĻ�
		if ($this->config['from_encoding'] == 'GBK' && in_array($this->config['to_encoding'], array('UTF-8', 'UNICODE', 'html-entities'))) {
			if ($gbk_unicode_table === NULL) {
				$gbk_unicode_table = unserialize(file_get_contents($this->config['codetable_dir'] . $this->config['GB2UNI_table']));
			}
			$this->unicodeTable = $gbk_unicode_table;
		}

		// ����ԭ����ΪBIG5�������ĵĻ�
		if ($this->config['from_encoding'] == 'BIG-5' && in_array($this->config['to_encoding'], array('UTF-8', 'UNICODE', 'html-entities'))) {
			if ($big5_unicode_table === NULL) {
				$big5_unicode_table = unserialize(file_get_contents($this->config['codetable_dir'] . $this->config['BIG52UNI_table']));
			}
			$this->unicodeTable = $big5_unicode_table;
		}

		// ����ԭ����Ϊ UTF8 �Ļ�
		if ($this->config['from_encoding'] == 'UTF-8' && $this->config['to_encoding'] == 'GBK') {
			if ($gbk_unicode_table === NULL) {
				$gbk_unicode_table = unserialize(file_get_contents($this->config['codetable_dir'] . $this->config['GB2UNI_table']));
			}
			$this->unicodeTable = array_flip($gbk_unicode_table);
		}

			// ����ת��Ŀ�����Ϊ BIG5 �Ļ�
		if ($this->config['from_encoding'] == 'UTF-8' && $this->config['to_encoding'] == 'BIG-5') {
			if ($big5_unicode_table === NULL) {
				$big5_unicode_table = unserialize(file_get_contents($this->config['codetable_dir'] . $this->config['BIG52UNI_table']));
			}
			$this->unicodeTable = array_flip($big5_unicode_table);
		}
	}

	/**
	 * �����塢�������ĵ� UNICODE ����ת��Ϊ UTF8 �ַ�
	 * @param int $c �������ĺ��ֵ�UNICODE�����10����
	 */
	private function UnicodeCharToUTF8($c) {
		$str = '';
		if ($c < 0x80) {
			$str .= chr($c);
		} elseif ($c < 0x800) {
			$str .= chr(0xC0 | $c >> 6);
			$str .= chr(0x80 | $c & 0x3F);
		} elseif ($c < 0x10000) {
			$str .= chr(0xE0 | $c >> 12);
			$str .= chr(0x80 | $c >> 6 & 0x3F);
			$str .= chr(0x80 | $c & 0x3F);
		} elseif ($c < 0x200000) {
			$str .= chr(0xF0 | $c >> 18);
			$str .= chr(0x80 | $c >> 12 & 0x3F);
			$str .= chr(0x80 | $c >> 6 & 0x3F);
			$str .= chr(0x80 | $c & 0x3F);
		}
		return $str;
	}

	/**
	 * ���塢�������� <-> UTF8 ����ת���ĺ���
	 */
	private function CHStoUTF8() {
		$len = strlen ( $this->sourceText );
		$i = 0;

		if ($this->config['from_encoding'] == 'BIG-5' || $this->config['from_encoding'] == 'GBK') {
			$ret = '';
			while ( $i < $len ) {
				if (ord ( $this->sourceText {$i} ) > 127) {
					$dec = hexdec ( bin2hex ( $this->sourceText {$i++} . $this->sourceText {$i++} ) );
					$ret .= $this->UnicodeCharToUTF8($this->unicodeTable [$dec]);
				} else {
					$ret .= $this->sourceText {$i++};
				}
			}
			$this->sourceText = '';
		}

		if ($this->config['from_encoding'] == 'UTF-8') {
			while ( $i < $len ) {
				$c = ord ( $this->sourceText {$i ++} );
				switch ($c >> 4) {
					case 0 :
					case 1 :
					case 2 :
					case 3 :
					case 4 :
					case 5 :
					case 6 :
					case 7 :
						// 0xxxxxxx
						$ret .= $this->sourceText {$i - 1};
						break;
					case 12 :
					case 13 :
						// 110x xxxx 10xx xxxx
						$char2 = ord ( $this->sourceText {$i ++} );
						$char3 = @$this->unicodeTable [(($c & 0x1F) << 6) | ($char2 & 0x3F)];

						if ($this->config['to_encoding'] == 'GBK') {
							$ret .= hex2bin( dechex ( $char3 ) );
						} elseif ($this->config['to_encoding'] == 'BIG-5') {
							$ret .= hex2bin( dechex ( $char3 ) );
						}
						break;
					case 14 :
						// 1110 xxxx 10xx xxxx 10xx xxxx
						$char2 = ord ( $this->sourceText {$i ++} );
						$char3 = ord ( $this->sourceText {$i ++} );
						$char4 = @$this->unicodeTable [(($c & 0x0F) << 12) | (($char2 & 0x3F) << 6) | (($char3 & 0x3F) << 0)];

						if ($this->config['to_encoding'] == 'GBK') {
							$ret .= hex2bin( dechex ( $char4 ) );
						} elseif ($this->config['to_encoding'] == 'BIG-5') {
							$ret .= hex2bin( dechex ( $char4 ) );
						}
						break;
				}
			}
		}

		return $ret;
	}

	/**
	 * ���塢��������ת��Ϊ UNICODE����
	 */
	private function CHStoUNICODE() {
		$utf = '';

		$from_encoding=$this->config['from_encoding'];
		$len=strlen($this->sourceText);
		$index=0;
		while ( $index<$len ) {
			try {
				if (ord ( $this->sourceText {$index} ) > 127) {
					$tableIndex = hexdec ( bin2hex ( $this->sourceText {$index} . $this->sourceText {$index+1} ) );
					if(isset($this->unicodeTable[$tableIndex])){
						$utf .= ('&#' . $this->unicodeTable[$tableIndex] . ';');
					}else{
						$utf .= self::BLANK_CHAR;
					}
					$index+=2;
				} else {
					$utf .= $this->sourceText {$index++};
				}
			} catch (Exception $e) {
				break;
			}
		}

		return $utf;
	}

	/**
	 * utf8תUnicode
	 */
	private function utf8ToUnicode() {
		$mState = 0; // cached expected number of octets after the current octet until the beginning of the next UTF8 character sequence
		$mUcs4 = 0;	 // cached Unicode character
		$mBytes = 1; // cached expected number of octets in the current sequence

		$ret = '';

		$str = $this->sourceText;
		$len = strlen ( $str );
		for($i = 0; $i < $len; $i ++) {
			$in = ord ( $str {$i} );
			if (0 == $mState) {
				// When mState is zero we expect either a US-ASCII character or a multi-octet sequence.
				if (0 == (0x80 & ($in))) {
					// US-ASCII, pass straight through.
					$s = str_pad(dechex($in), 4, '0', STR_PAD_LEFT);
					$ret .= hex2bin($s);
					$mBytes = 1;
				} else if (0xC0 == (0xE0 & ($in))) {
					// First octet of 2 octet sequence
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x1F) << 6;
					$mState = 1;
					$mBytes = 2;
				} else if (0xE0 == (0xF0 & ($in))) {
					// First octet of 3 octet sequence
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x0F) << 12;
					$mState = 2;
					$mBytes = 3;
				} else if (0xF0 == (0xF8 & ($in))) {
					// First octet of 4 octet sequence
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x07) << 18;
					$mState = 3;
					$mBytes = 4;
				} else if (0xF8 == (0xFC & ($in))) {
					/*
					 * First octet of 5 octet sequence. This is illegal because the
					 * encoded codepoint must be either (a) not the shortest form or
					 * (b) outside the Unicode range of 0-0x10FFFF. Rather than
					 * trying to resynchronize, we will carry on until the end of
					 * the sequence and let the later error handling code catch it.
					 */
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x03) << 24;
					$mState = 4;
					$mBytes = 5;
				} else if (0xFC == (0xFE & ($in))) {
					// First octet of 6 octet sequence, see comments for 5 octet
					// sequence.
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 1) << 30;
					$mState = 5;
					$mBytes = 6;
				} else {
					/*
					 * Current octet is neither in the US-ASCII range nor a legal
					 * first octet of a multi-octet sequence.
					 */
					return false;
				}
			} else {
				// When mState is non-zero, we expect a continuation of the
				// multi-octet
				// sequence
				if (0x80 == (0xC0 & ($in))) {
					// Legal continuation.
					$shift = ($mState - 1) * 6;
					$tmp = $in;
					$tmp = ($tmp & 0x0000003F) << $shift;
					$mUcs4 |= $tmp;

					if (0 == -- $mState) {
						//End of the multi-octet sequence. mUcs4 now contains the final Unicode codepoint to be output Check for illegal sequences and codepoints.

						// From Unicode 3.1, non-shortest form is illegal
						if (((2 == $mBytes) && ($mUcs4 < 0x0080)) || ((3 == $mBytes) && ($mUcs4 < 0x0800)) || ((4 == $mBytes) && ($mUcs4 < 0x10000)) || (4 < $mBytes) ||
								// From Unicode 3.2, surrogate characters are illegal
								(($mUcs4 & 0xFFFFF800) == 0xD800) ||
								// Codepoints outside the Unicode range are illegal
								($mUcs4 > 0x10FFFF)) {
							return false;
						}
						if (0xFEFF != $mUcs4) {
							// BOM is legal but we don't want to output it
							$addzero = '';
							$ret .= hex2bin(dechex($mUcs4));
						}
						// initialize UTF8 cache
						$mState = 0;
						$mUcs4 = 0;
						$mBytes = 1;
					}
				} else {
					// ((0xC0 & (*in) != 0x80) && (mState != 0)) Incomplete multi-octet sequence.
					return false;
				}
			}
		}
		return $ret;
	}

	/**
	 * utf8תʵ�����html-entities
	 */
	private function utf8ToHtmlentities() {
		$mState = 0; // cached expected number of octets after the current octet until the beginning of the next UTF8 character sequence
		$mUcs4 = 0;	 // cached Unicode character
		$mBytes = 1; // cached expected number of octets in the current sequence

		$ret = '';

		$str = $this->sourceText;
		$len = strlen ( $str );
		for($i = 0; $i < $len; $i ++) {
			$in = ord ( $str {$i} );
			if (0 == $mState) {
				// When mState is zero we expect either a US-ASCII character or a multi-octet sequence.
				if (0 == (0x80 & ($in))) {
					// US-ASCII, pass straight through.
					$ret .= chr($in);
					$mBytes = 1;
				} else if (0xC0 == (0xE0 & ($in))) {
					// First octet of 2 octet sequence
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x1F) << 6;
					$mState = 1;
					$mBytes = 2;
				} else if (0xE0 == (0xF0 & ($in))) {
					// First octet of 3 octet sequence
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x0F) << 12;
					$mState = 2;
					$mBytes = 3;
				} else if (0xF0 == (0xF8 & ($in))) {
					// First octet of 4 octet sequence
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x07) << 18;
					$mState = 3;
					$mBytes = 4;
				} else if (0xF8 == (0xFC & ($in))) {
					/*
					 * First octet of 5 octet sequence. This is illegal because the
					* encoded codepoint must be either (a) not the shortest form or
					* (b) outside the Unicode range of 0-0x10FFFF. Rather than
					* trying to resynchronize, we will carry on until the end of
					* the sequence and let the later error handling code catch it.
					*/
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 0x03) << 24;
					$mState = 4;
					$mBytes = 5;
				} else if (0xFC == (0xFE & ($in))) {
					// First octet of 6 octet sequence, see comments for 5 octet
					// sequence.
					$mUcs4 = ($in);
					$mUcs4 = ($mUcs4 & 1) << 30;
					$mState = 5;
					$mBytes = 6;
				} else {
					/*
					 * Current octet is neither in the US-ASCII range nor a legal
					* first octet of a multi-octet sequence.
					*/
					return false;
				}
			} else {
				// When mState is non-zero, we expect a continuation of the
				// multi-octet
				// sequence
				if (0x80 == (0xC0 & ($in))) {
					// Legal continuation.
					$shift = ($mState - 1) * 6;
					$tmp = $in;
					$tmp = ($tmp & 0x0000003F) << $shift;
					$mUcs4 |= $tmp;

					if (0 == -- $mState) {
						//End of the multi-octet sequence. mUcs4 now contains the final Unicode codepoint to be output Check for illegal sequences and codepoints.

						// From Unicode 3.1, non-shortest form is illegal
						if (((2 == $mBytes) && ($mUcs4 < 0x0080)) || ((3 == $mBytes) && ($mUcs4 < 0x0800)) || ((4 == $mBytes) && ($mUcs4 < 0x10000)) || (4 < $mBytes) ||
								// From Unicode 3.2, surrogate characters are illegal
								(($mUcs4 & 0xFFFFF800) == 0xD800) ||
								// Codepoints outside the Unicode range are illegal
								($mUcs4 > 0x10FFFF)) {
							return false;
						}
						if (0xFEFF != $mUcs4) {
							// BOM is legal but we don't want to output it
							$addzero = "";
							$ret .= '&#' . $mUcs4 . ';';
						}
						// initialize UTF8 cache
						$mState = 0;
						$mUcs4 = 0;
						$mBytes = 1;
					}
				} else {
					// ((0xC0 & (*in) != 0x80) && (mState != 0)) Incomplete multi-octet sequence.
					return false;
				}
			}
		}
		return $ret;
	}

	/**
	 * Unicodeתʵ�����html-entities
	 * Takes an array of ints representing the Unicode characters and returns a UTF-8 string.
	 * Astral planes are supported ie. the ints in the input can be > 0xFFFF. Occurrances of the BOM are ignored. Surrogates are not allowed.
	 * Returns false if the input array contains ints that represent surrogates or are outside the Unicode range.
	 */
	private function unicodeToHtmlentities() {
		$ret = '';
		$arr=str_split($this->sourceText,1024);
		foreach($arr as $block){
			$ascs=unpack("n*", $block);
			foreach ( $ascs as $asc ) {
				if($asc<127)
					$ret .= chr($asc);
				else
					$ret .= '&#' . $asc . ';';
			}
		}
		return $ret;
	}

	/**
	 * Unicodeתutf8
	 * Takes an array of ints representing the Unicode characters and returns a UTF-8 string.
	 * Astral planes are supported ie. the ints in the input can be > 0xFFFF. Occurrances of the BOM are ignored. Surrogates are not allowed.
	 * Returns false if the input array contains ints that represent surrogates or are outside the Unicode range.
	 */
	private function unicodeToUtf8() {
		$ret = '';
		$arr=str_split($this->sourceText,1024);
		foreach($arr as $block){
			$ascs=unpack("n*", $block);
			foreach ( $ascs as $src ) {
				if ($src < 0) {
					return false;
				} else if ($src <= 0x007f) {
					$ret .= chr ( $src & 0xFF );
				} else if ($src <= 0x07ff) {
					$ret .= chr ( 0xc0 | ($src >> 6) );
					$ret .= chr ( 0x80 | ($src & 0x003f) );
				} else if ($src == 0xFEFF) {
					// nop -- zap the BOM
				} else if ($src >= 0xD800 && $src <= 0xDFFF) {
					// found a surrogate
					return false;
				} else if ($src <= 0xffff) {
					$ret .= chr ( 0xe0 | ($src >> 12) );
					$ret .= chr ( 0x80 | (($src >> 6) & 0x003f) );
					$ret .= chr ( 0x80 | ($src & 0x003f) );
				} else if ($src <= 0x10ffff) {
					$ret .= chr ( 0xf0 | ($src >> 18) );
					$ret .= chr ( 0x80 | (($src >> 12) & 0x3f) );
					$ret .= chr ( 0x80 | (($src >> 6) & 0x3f) );
					$ret .= chr ( 0x80 | ($src & 0x3f) );
				} else {
					// out of range
					return false;
				}
			}
		}
		return $ret;
	}
}

?>
