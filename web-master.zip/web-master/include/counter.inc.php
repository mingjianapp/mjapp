<?php
defined('BAR_ENABLE_BUTTONS') or define('BAR_ENABLE_BUTTONS', true);
define('BAR_LINE_WIDTH', 15);
define('BAR_LINE_MARGIN', 15);
define('BAR_LABEL_HEIGHT', 15);
define('BAR_TITLE_HEIGHT', 30);
define('BAR_V_HEIGHT', 150);
define('BAR_H_WIDTH', 550);
define('BAR_COLUMN_WIDTH', BAR_LINE_WIDTH+BAR_LINE_MARGIN);
define('BAR_ROW_HEIGHT', BAR_LINE_WIDTH+BAR_LINE_MARGIN);
header('Content-Type: text/html; charset=GBK');
$showDomainList = empty($_COOKIE['_show_d_']) ? 0 : 1;

if(empty($option['file']) && empty($option['data'])){
    exit('����ͳ������');
}

if(APP_CHARSET!='GBK'){
	foreach($option as $k=>$v){
		$option[$k] = mb_convert_encoding($v, 'GBK', APP_CHARSET);
	}
}


//��ʾͳ��ͼ��(�������״ͼ)
function show_bar_v($arr, $keyMap){
    $max_v = max(array_values($arr));
	$index = 0;
	$count = count($arr);
	echo "<div class='canvas_v' style='width:" .(BAR_COLUMN_WIDTH*$count+BAR_LINE_MARGIN). "px;'>";
	foreach($arr as $k=>$v){
	    if(is_null($v)) break;
	    if($keyMap!==null) $k = isset($keyMap[$k]) ? $keyMap[$k] : "{$k}. δ�ҵ�";
	    $height = $max_v ? intval(BAR_V_HEIGHT*$v/$max_v) : 0;
	    $top = BAR_V_HEIGHT+BAR_LABEL_HEIGHT-$height-1;
		$left = $index * BAR_COLUMN_WIDTH + BAR_LINE_MARGIN/2;
		if($v>0) {
		    echo '<div class="label" style="left:'.$left.'px; top:'.($top-BAR_LABEL_HEIGHT).'px;">'.$v.'</div>';
            echo '<div class="column" style="height:'.$height.'px; left:'.$left.'px; top:'.$top.'px;"></div>';
		}
		echo '<div class="xvalue" style="left:'.$left.'px; top:'.(BAR_V_HEIGHT+BAR_LABEL_HEIGHT).'px;">'.$k.'</div>';
	    $index++;
	}
	echo "</div>";
}

//��ʾͳ��ͼ��(�������״ͼ)
function show_bar_h($arr, $keyMap){
    $max_v = max(array_values($arr));
    $index = 0;
    $count = count($arr);
    echo "<div class='yvalue' style='height:".(BAR_ROW_HEIGHT*$count)."px;'>";
    foreach($arr as $k=>$v) {
        if($keyMap!==null) $k = isset($keyMap[$k]) ? $keyMap[$k] : "<div class='pagename'>{$k}. δ�ҵ�</div>";
        echo $k;
    }
    echo "</div>";
    echo "<div class='canvas_h' style='height:".(BAR_ROW_HEIGHT*$count)."px;'>";
    foreach($arr as $v) {
        if($v<=0) continue;
        $width = $max_v ? intval(BAR_H_WIDTH*$v/$max_v) : 0;
        $top = BAR_ROW_HEIGHT*$index;
        $labelLeft = $width + 1;
        echo '<div class="label" style="left:'.$labelLeft.'px; top:'.$top.'px;">'.$v.'</div>';
        echo '<div class="row" style="width:'.$width.'px; top:'.$top.'px;"></div>';
        $index++;
    }
    echo "</div><div style='clear:both;'></div>";
}

//��ʾͳ��ͼ��(����key�ĸ����Զ�ѡ���Ǻ���ͼ����������ͼ��)
function show_bar($arr, $title, $barStyle=null, $keyMap=null){
    $count = count($arr);
    if(empty($barStyle)){
        $barStyle = $count<=31 ? 'v' : 'h';
    }
    echo "<div class='bar bar_{$barStyle}'>";
    echo "<div class='title'>{$title}</div>";
    if($count==0){
        echo '��������';
    }else{
        if($barStyle=='v'){
            echo show_bar_v($arr, $keyMap);
        }else{
            echo show_bar_h($arr, $keyMap);
        }
    }
    echo "</div>";
}


$counter_file = isset($option['file']) ? $option['file'] : '';
if($counter_file && file_exists($counter_file)){
    $counts=file_get_contents_safe($counter_file);
    if($counts){
    	$counts=unserialize($counts);
    }elseif(file_exists($counter_file.'.bak')){
    	$counts=unserialize(file_get_contents($counter_file.'.bak'));
    }else{
    	$counts=array();
    }
}elseif(!empty($option['data']) && is_array($option['data'])){
    $counter_file = '';
    $counts=$option['data'];
}

if($counter_file && isset($_GET['deldoamin'])){
	$domain=trim($_GET['deldoamin']);
	if(isset($counts['domains'],$counts['domains'][$domain])){
		unset($counts['domains'][$domain]);
		file_put_contents($counter_file, serialize($counts), LOCK_EX);
		echo '<script type="text/javascript">parent.blank(); parent.location.reload();</script>';
	}
	exit;
}elseif($counter_file && isset($_GET['setremark'])){
	$domain=trim($_GET['setremark']);
	$remark=mb_convert_encoding(trim($_GET['remark']), 'gbk', 'utf-8');
	if(isset($counts['domains'],$counts['domains'][$domain])){
		$counts['domains'][$domain][6]=$remark;
		file_put_contents($counter_file, serialize($counts), LOCK_EX);
		echo '<script type="text/javascript">parent.blank(); parent.location.reload();</script>';
	}
	exit;
}
?>
<!doctype html><html>
<head>
<meta http-equiv="content-type" content="text/html; charset=gbk">
<title><?php echo $option['title']; ?></title>
<style>
body{line-height:20px; width:980px;}
.clear{clear:both;}
.bar{margin:5px; padding:5px 0 0 10px; background-color:#FDFDFD; border:1px solid #CCC;}
.bar_h{padding-bottom:10px;}
.bar .title{height:<?php echo BAR_TITLE_HEIGHT; ?>px; line-height:<?php echo BAR_TITLE_HEIGHT; ?>px; font-size:16px; font-weight:bold; text-align:center;}
.canvas_v{position:relative; border-left:solid #333 1px; border-bottom:solid #333 1px; margin:0 0 20px 5px; height:<?php echo BAR_V_HEIGHT+BAR_LABEL_HEIGHT; ?>px;}
.canvas_h{position:relative; border-left:solid #333 1px; border-bottom:solid #333 1px; margin:0 0 5px 0; float:left; width:<?php echo BAR_H_WIDTH+BAR_LINE_MARGIN; ?>px;}
.column{position:absolute; width:<?php echo BAR_LINE_WIDTH; ?>px; margin:0 <?php echo BAR_LINE_MARGIN/2; ?>px; border:solid 1px #CCC; border-bottom:none; background-color:#EEE;}
.row{position:absolute; height:<?php echo BAR_LINE_WIDTH; ?>px; margin:<?php echo BAR_LINE_MARGIN/2; ?>px 0; left:0; border:solid 1px #CCC; border-left:none; background-color:#EEE;}
.xvalue{position:absolute; height:<?php echo BAR_LABEL_HEIGHT; ?>px; line-height:<?php echo BAR_LABEL_HEIGHT; ?>px; width:<?php echo BAR_COLUMN_WIDTH; ?>px; font-size:12px; text-align:center; color:#333;}
.yvalue{width:10px; white-space:nowrap; display:table; float:left; line-height:<?php echo BAR_ROW_HEIGHT; ?>px; text-align:right; padding:0 5px; color:#333; font-size:12px;}
.label{position:absolute; font-size:12px; color:#666;}
.canvas_v .label{height:<?php echo BAR_LABEL_HEIGHT; ?>px; line-height:<?php echo BAR_LABEL_HEIGHT; ?>px; width:<?php echo BAR_COLUMN_WIDTH; ?>px; text-align:center;}
.canvas_h .label{height:<?php echo BAR_ROW_HEIGHT; ?>px; line-height:<?php echo BAR_ROW_HEIGHT; ?>px; text-align:left; margin-left:3px;}
#desc{background-color:#DDD; margin:5px 0; padding:10px; color:#333;}
h1{font-size:20px; height:<?php echo BAR_TITLE_HEIGHT; ?>px; line-height:<?php echo BAR_TITLE_HEIGHT; ?>px;}
h1 a{color:blue;}
#h1s{line-height:25px;}
#h1s h1{float:left; margin:10px 30px 10px 0px;}
table{ table-layout:fixed; empty-cells:show; border-collapse:collapse;}
th{text-align:center;}
table.t1{ border:1px solid #cad9ea;color:#666;}
table.t1 th { padding:2px 10px; border:1px solid #cad9ea; background-color:#F0F5F9;height:20px;}
table.t1 td { padding:2px; border:1px solid #cad9ea;}
table.t1 tr.a1{ background-color:#f5fafe;}
button {color:12px;padding:1px 4px;}
.caution{padding:5px; margin:10px 0; border:1px solid #CCC; background-color:#ece76b; font-size:12px; line-height:20px; color:#ff0606;}
#ruler {visibility:hidden; white-space:nowrap; font-size:24px;}
a.pagename{display:block; max-width:300px; overflow:hidden; white-space:nowrap; text-overflow:ellipsis;}
</style>
<script type="text/javascript">
function delDomain($domain){
	if(confirm('ȷʵҪɾ���������ļ�¼��')){
		var frame=document.getElementById('_hiddenframe');
		frame.src='?<?php echo trim($_SERVER['QUERY_STRING'],'&'); ?>&deldoamin='+$domain+'&t='+(new Date).getTime();
	}
}
function blank(){
	var frame=document.getElementById('_hiddenframe');
	frame.src='about:blank';
}
function setRemark(domain, row){
	var remark = document.getElementById('remark_'+row).innerHTML;
	var frame=document.getElementById('_hiddenframe');
	var newremark = window.prompt('������ '+domain+' �ı�ע˵����', remark);
	if(newremark!=remark && typeof newremark=='string'){
		frame.src='?<?php echo trim($_SERVER['QUERY_STRING'],'&'); ?>&setremark='+domain+'&remark='+encodeURIComponent(newremark);
	}
}
function setAliveDays(){
	var s = document.getElementById('alive-days').value;
	if(!s || !s.match(/^\d+$/)){
		alert('����������');
		return false;
	}
	var t = new Date(); t.setTime(t.getTime()+365*86400*1000);
	document.cookie = '_a_days_='+s+'; expires=' + t.toGMTString();
	var url = location.href.replace(/#.*$/,'').replace(/[\?&](_=\d+)?$/,'');
	url += url.indexOf('?')===-1 ? '?' : '&';
	url += '_='+(+new Date());
	location.href = url+'#domain';
}
function toggleDomainList(){
	var t = new Date(); t.setTime(t.getTime()+7*86400*1000);
	document.cookie = '_show_d_=<?php echo 1-$showDomainList; ?>; expires=' + t.toGMTString();
	var url = location.href.replace(/#.*$/,'').replace(/[\?&](_=\d+)?$/,'');
	url += url.indexOf('?')===-1 ? '?' : '&';
	url += '_='+(+new Date());
	location.href = url+'#domain';
}
String.prototype.visualLength = function(){
    var ruler = $("#ruler");
    ruler.text(this);
    return ruler[0].offsetWidth;
};
</script>
</head>

<body>
<?php echo isset($option['header']) ? $option['header'] : "<h1>{$option['title']}</h1>"; ?>
<div style="clear:both;"></div>
<div id="desc"><?php echo $option['desc']; ?></div>

<?php
if(empty($counts)) {
	exit('��û���κ�'.$option['name'].'�ļ�¼');
}

$x = intval(substr($counts['date'],6,2));
$total_thisday = isset($counts['thism'][$x]) ? $counts['thism'][$x] : 0;

//����·��Ƿ�����
$recordMonth = substr($counts['date'],0,6);
if($recordMonth == date('Ym')){
	$total_lastm = intval(@$counts[date('Ym',strtotime('first day of -1 month'))]);
	$total_thism = array_sum(array_values($counts['thism']));
}else{
	$lastMonth = date('Ym',strtotime('first day of -1 month'));
	if($recordMonth==$lastMonth){
		$counts['lastm'] = $counts['thism'];
		$total_lastm = array_sum(array_values($counts['thism']));
	}else{
		$counts['lastm'] = array();
		$total_lastm = intval(@$counts[date('Ym',strtotime('first day of -1 month'))]);
	}
	$counts['thism']=array();
	$total_thism = 0;
}

echo '<br/>'.$option['name'].'������<b>'.$counts['all'].'</b>';
echo '<br/><br/>����'.$option['name'].'������<b>'.$total_lastm.'</b>';
echo '<br/><br/>����'.$option['name'].'������<b>'.$total_thism.'</b>';
echo '<br/><br/>���'.$option['name'].'���ڣ�<b>'.substr($counts['date'],0,4).'��'.substr($counts['date'],4,2).'��'.substr($counts['date'],6,2).'��</b>';
echo '<br/>����'.$option['name'].'������<b>'.$total_thisday.'</b>';
echo '<br/><br/>';

$arr = $counts['thism'];
$lastday = intval(date('d'));
for($i=1;$i<=$lastday;$i++){
    if(!isset($arr[$i])) $arr[$i]=0;
}
ksort($arr);
for($i=$lastday+1;$i<=31;$i++){
    $arr[$i]=null;
}
show_bar($arr, '����ÿ��'.$option['name'].'��ϸ');
echo '<br/>';

$arr = $counts['lastm'];
$lastday = intval(date('t', strtotime("-1 month")));
for($i=1;$i<=$lastday;$i++){
    if(!isset($arr[$i])) $arr[$i]=0;
}
ksort($arr);
for($i=$lastday+1;$i<=31;$i++){
    $arr[$i]=null;
}
show_bar($arr, '����ÿ��'.$option['name'].'��ϸ');
echo '<br/>';

$hour=intval(date('Ymd').'01');
$h=intval(date('H'));
$arr=array();
for($i=1;$i<=$h;$i++){
    $arr[$i]=isset($counts['hour'][$hour+$i-1])?$counts['hour'][$hour+$i-1]:0;
}
ksort($arr);
for($i=count($arr)+1;$i<=24;$i++){
    $arr[$i]=null;
}
show_bar($arr, '���շ�ʱ��'.$option['name'].'��ϸ');
echo '<br/>';

$hour=intval(date('Ymd',strtotime('-1 day')).'01');
$arr=array();
for($i=1;$i<=24;$i++){
    $arr[$i]=isset($counts['hour'][$hour+$i-1])?$counts['hour'][$hour+$i-1]:0;
}
ksort($arr);
for($i=count($arr)+1;$i<=24;$i++){
    $arr[$i]=null;
}
show_bar($arr, '���շ�ʱ��'.$option['name'].'��ϸ');
echo '<br/>';

if(!empty($address_counter)){
    $data_year = $data_month = $data_yesterday = $data_today = array();
    $day_lastyear = date('Ymd', strtotime("-1 year"));
    $day_lastmonth = date('Ymd', strtotime("-1 month"));
    $day_yesterday = date('Ymd', strtotime("-1 day"));
    $day_today = date('Ymd');
    foreach($address_counter as $k=>$v){
        $data_year[$k] = $data_month[$k] = $data_yesterday[$k] = $data_today[$k] = 0;
        foreach($v as $k2=>$v2){
            //��ȡ���1������ַ�������
            if($k2>=$day_lastyear) $data_year[$k]+=$v2;
            //��ȡ���1���¿����ַ�������
            if($k2>=$day_lastmonth) $data_month[$k]+=$v2;
            //��ȡ���տ����ַ�������
            if($k2==$day_yesterday) $data_yesterday[$k]+=$v2;
            //��ȡ���տ����ַ�������
            if($k2==$day_today) $data_today[$k]+=$v2;
        }
        if($data_year[$k]==0) unset($data_year[$k]);
        if($data_month[$k]==0) unset($data_month[$k]);
        if($data_yesterday[$k]==0) unset($data_yesterday[$k]);
        if($data_today[$k]==0) unset($data_today[$k]);
    }

    if(empty($address)) {
        $keyMap = null;
    }else{
        //��/data/address.dat��������$address�б�
        if(file_exists(DATADIR.'/address.dat')){
            $lines = file(DATADIR.'/address.dat');
            foreach($lines as $line){
                $record = explode('|', rtrim($line));
                if(count($record)==3 && !isset($address[$record[0]])){
                    $address[$record[0]] = "{$record[1]}|{$record[2]}";
                }
            }
        }

        $keyMap = array();
        foreach($address as $k=>$v){
            $arr = explode('|',$v,2);
            if(count($arr)==2){
                $title = !empty($arr[0]) ? $arr[0] : $arr[1];
                $keyMap[$k] = "<a href='{$arr[1]}' target='_blank' title='����Դ��վ' class='pagename'>{$k}. {$title}</a>";
            }else{
                $keyMap[$k] = "<a href='{$v}' target='_blank' title='����Դ��վ' class='pagename'>{$k}. {$v}</a>";
            }
        }
    }

    ksort($data_year, SORT_NUMERIC);
    show_bar($data_year, '�����ַ���1��������', 'h', $keyMap);
    echo '<br/>';

    ksort($data_month, SORT_NUMERIC);
    show_bar($data_month, '�����ַ���1���·������', 'h', $keyMap);
    echo '<br/>';

    ksort($data_yesterday, SORT_NUMERIC);
    show_bar($data_yesterday, '�����ַ����������', 'h', $keyMap);
    echo '<br/>';

    ksort($data_today, SORT_NUMERIC);
    show_bar($data_today, '�����ַ����������', 'h', $keyMap);
    echo '<br/>';
}
echo '<br/>';


$aliveDays = isset($_COOKIE['_a_days_']) ? intval($_COOKIE['_a_days_']) : 0;
if($aliveDays<=0) $aliveDays=3;

$maxDaysTips = defined('DOMAIN_MAX_DAYS') ? ('������ͳ��'.DOMAIN_MAX_DAYS.'�죩') : '';

echo "<h2>����������ͳ��<button onclick='{toggleDomainList(); return false;}' style='margin-left:10px;'> " . ($showDomainList?'����':'��ʾ') . " </button></h2><a name='domain'></a>";
if($showDomainList){
    echo "<div style='margin:5px 0; padding:5px 10px; background-color:#FDFDFD; border:1px solid #ccc; width:420px; font-size:13px;'>����ʾ <input id='alive-days' value='{$aliveDays}' size='3' maxlength='3'> �����й����ʼ�¼������ {$maxDaysTips} <button onclick='{setAliveDays(); return false;}'>  ȷ ��  </button></div>
    <table border='1' class='t1'>
    <tr>
    	<th nowrap>����</th>
    	<th nowrap>���˴�</th>
    	<th nowrap>����·�</th>
    	<th nowrap>�����˴�</th>
    	<th nowrap>�������</th>
    	<th nowrap>�����˴�</th>
    	<th nowrap>����������</th>
        <th nowrap>��ע˵��</th>";
        if(BAR_ENABLE_BUTTONS){
            echo "<th nowrap width='100'>����</th>";
        }
    echo "</tr>";
    if(is_array($counts['domains'])){
    	$row=0;
    	foreach($counts['domains'] as $domain=>$domainCounter){
    		if(isset($domainCounter[5]) && $domainCounter[5]){
    			$days = floor((time()-intval($domainCounter[5]))/86400);
    		}else{
    			$days = '';
    		}
    		if($days>$aliveDays) continue;
    		echo "<tr class='a". ($row++ % 2) ."'>
    		<td align='left'>{$domain}</td>
    		<td align='right'>{$domainCounter[0]}</td>
    		<td align='center'>{$domainCounter[1]}</td>
    		<td align='right'>{$domainCounter[2]}</td>
    		<td align='center'>{$domainCounter[3]}</td>
    		<td align='right'>{$domainCounter[4]}</td>
    		<td align='right'>{$days}</td>
            <td align='left' id='remark_{$row}'>" .(isset($domainCounter[6])?$domainCounter[6]:''). "</td>";
    		if(BAR_ENABLE_BUTTONS){
        		echo "<td align='center' nowrap><button onclick=\"setRemark('{$domain}',$row);\">��ע</button> <button onclick=\"delDomain('{$domain}');\">ɾ��</button></td>";
            }
    	echo "</tr>";
    	}
    }
    echo '</table>
    <div style="color:#666; margin-top:10px;">˵��1:����������������ʾ�Ѿ�������û�б����ʹ��ˡ�</div>
    <div style="color:#666; margin-top:10px;">˵��2:�������ÿ�����ָ���Ƿ���ĳ��ҳ����������ÿ͵Ķ���ظ����ֻ���¼һ�Ρ���վʹ��COOKIE��ʶ���������Ƿ����µķÿͣ�����ÿͷ��ʹ�������������COOKIE���ߴ���������������ᱻʶ��Ϊһ���·ÿͣ�����������������IP�������ᵼ�¼��������ӡ�</div>';
}
?>
<br/><br/>

<span id="ruler"></span>
<iframe id='_hiddenframe' width='0' height='0' style='display:none;'></iframe>
</body>
</html>
