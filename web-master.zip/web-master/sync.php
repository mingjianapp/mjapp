<?php

/**
 * �������ķ���
 */

require('common.inc.php');
require(APPDIR.'/config.inc.php');
require(APPDIR.'/include/func.inc.php');
require(APPDIR.'/include/http.inc.php');
require(APPDIR.'/include/coding.inc.php');

define('DOMAIN_MAX_DAYS', 7);
header('Content-Type: text/html; charset='.APP_CHARSET);

//=====================================================================================
//================ ��ʼ��������ַ� ======================================================
//=====================================================================================

//��ʼ��
init_config();

$sync_dir = DATADIR.'/~sync';
$sync_server_files = array(
	'log' => $sync_dir.'/~log.dat',
	'active' => $sync_dir.'/~active.dat',
	'client' => $sync_dir.'/~client_info.dat',
	'md5' => $sync_dir.'/~client_hash.dat',
);
$sync_client_files = array(
	'client' => DATADIR.'/~sync_client_id.dat',
	'mark_download' => TEMPDIR.'/~sync_mark_download.~tmp',
	'mark_upload' => TEMPDIR.'/~sync_mark_upload.~tmp',
);
$all_download_files = array('address.dat','ats.dat','faq.dat','video.dat','white_domains.dat');
$all_upload_files = array('~counter_visit.dat', '~counter_visit_faq.dat', '~counter_visit_video.dat', '~counter_visit_address.dat', '~counter_3tui.dat'); // '~counter_play_video.dat');
$upload_options = array(
	'v' =>	   array('title'=>'�ÿ�ͳ��', 'name'=>'�ÿ�', 'file'=>$all_upload_files[0], 'desc'=>'����ͳ�Ƶ��Ƿ��ʴ���ҳ��Ķ����ÿ���'),
	'v_faq' =>   array('title'=>'�ʴ�ÿ�ͳ��', 'name'=>'�ÿ�', 'file'=>$all_upload_files[1], 'desc'=>'����ͳ�Ƶ��������ʴ�ҳ��faq.php���õĶ����ÿ���'),
	'v_video' => array('title'=>'Ӱ���ÿ�ͳ��', 'name'=>'�ÿ�', 'file'=>$all_upload_files[2], 'desc'=>'����ͳ�Ƶ�������Ӱ��ҳ�棨������ҳ�Ͳ���ҳ�����õĶ����ÿ���'),
//	'play' =>	array('title'=>'Ӱ������ͳ��', 'name'=>'����', 'file'=>$all_upload_files[3], 'desc'=>'����ͳ�Ƶ�������Ӱ�������ŵĴ���'),
	'3t' =>	  array('title'=>'ֱ������ͳ��', 'name'=>'����', 'file'=>$all_upload_files[4], 'desc'=>'����ͳ�Ƶ��ǳɹ���������ύ�Ĵ���������������������˵����M���ύ�ģ�����ͨ���ײ����������ٵģ�ֻҪ������˵���վ���ύ���ҳ����ʾΪ�ύ�ɹ��ģ��������ڴ��M��ͳ�ơ�'),
);


$page = isset($_GET['page']) ? $_GET['page'] : '';
unset($_GET['page'],$_GET['_ver']);
check_sync_server($page);
if(!empty($_GET['tjid']) && !$upload_options[$_GET['tjid']]) unset($_GET['tjid']);
if(!empty($_GET['id']) && preg_match('#[^\w\-\.]#', $_GET['id'])) unset($_GET['id']);
if(!empty($_GET['info'])) $_GET['info'] = preg_replace('#[^'.chr(0xa1).'-'.chr(0xff).'\w\-\.]#', '', $_GET['info']);

switch($page){
	case 'alllog':
	case 'log':
		//��ʾ��־
		showLog($page=='alllog');
		break;
	case 'active':
		//��������̨�鿴��������״̬����
		showActive();
		break;
	case 'rename':
		set_client_info($_GET['id'],$_GET['info']);
		break;
	case 'tj':
		//��������̨�鿴ͳ������
		if(empty($_GET['tjid'])){
			showError();
		}else{
			showCounter();
		}
		break;
	case 'client':
		//����
		if(DEBUGING>1) {
			@unlink($sync_client_files['mark_download']);
			@unlink($sync_client_files['mark_upload']);
		}
		$markFile = $sync_client_files['mark_upload'];
		$mtime = file_exists($markFile) ? filemtime($markFile) : 0;
		if(time()-$mtime>600){
			//�����û��жϺͳ�ʱ
			@ignore_user_abort(true);
			//�ӿͻ��˷�������
			if(empty($_GET) && empty($_POST)){
				sync_client_download();
				sync_client_upload();
			}
		}
		break;
	case 'server':
		//�����ͻ�������
		if(empty($_GET) && count($_POST)===1 && !empty($_POST['data'])) {
			sync_server_dispose();
		}
		break;
	default:
		showError();
}


//=====================================================================================
//================ ��̨���� =============================================================
//=====================================================================================

function showHead(){
	global $upload_options, $page, $sync_dir, $config;
	check_authentication($config['password']);

	echo '<!DOCTYPE html><html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=gbk">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
	<style type="text/css">
		body{margin:0;padding:5px;}
		#top-menu{line-height:30px;background-color:#F6F6F6;border-bottom:1px solid #65748A;}
		.menu a{margin-left:10px;color:#000;text-decoration:none;}
		.menu a:hover{color:red;}
		.menu a.active{color:red;font-weight:bold;}
		.menu span{margin-left:10px;}
		.menu b{font-weight:normal;margin-left:10px;color:#afadad;}
        #client-menu{line-height:30px;background-color:#F6F6F6;border-bottom:2px solid #65748A;}
        #client-menu a{display:inline-block;}
		table{table-layout:fixed; *table-layout:auto; empty-cells:show; border-collapse:collapse; width:auto;}
		table.t1{border:1px solid #cad9ea;color:#333;}
		table.t1 th{background-color:#F0F5F9;height:20px;}
		table.t1 td, table.t1 th{border:1px solid #cad9ea;padding:3px 5px 3px; word-wrap:break-word;}
		table.t1 tr.a1{background-color:#f5fafe;}
		table.t1 tr.active{background-color:rgb(248,226,226);}
		.tips{color:#999;}
        .client_fold{display:block; float:left; cursor:pointer; width:20px; height:20px; margin:0 5px 0 0; background-image:url("data:image/gif;base64,R0lGODlhFAAUANU/AP////n//1paWkpGQsbt/01IQo6OjmZmZnFxcWVWR3x8fGnE/87//6qqqlRMRIiIiIe256fK7VJFNz0vIWe0/2NWSdL0/2NTQl5PP67e/0pDO2Gw/vr//5nS/1BKQ7e3t8fe9cje9WRURFW3/1hNQYPD/3/B/7/Z8kc/N1ZWVqKiorHQ75a/6k5HP1hJO5fR/3iu5Y+Pj8Xs/8bd9FRUVNHj9qGhoc7h9sPr/7KyssvLy1M8JVZHOMPDw7XS8f///yH5BAEAAD8ALAAAAAAUABQAQAaYwJ9wSCwahQUAJ8C5nVaZTmnhahyJH4PCoLoakxYGyur9fWIIUgdiqtAEili3TL9qADVcC6HzOhgEMgQrESwvJhQjFwplPAsbIyIIOXWVlpYHBR4OApcDASAEGg9lmQMDE6AEOyQSCZ1GHhYhMyEnPoUQMBsYBkYHKBotOxkRLzsVCSIpvlc9EiUwFK82lQcuGBcppJfdl0EAOw==");}
        .client_unfold{display:block; float:left; cursor:pointer; width:20px; height:20px; margin:0 5px 0 0; background-image:url("data:image/gif;base64,R0lGODlhFAAUANU8AAAAAP///7XS8WGw/niu5Ye255fA6qfK7cbd9Mje9Wa0/4HD/4PD/7/Z8pbQ/53T/1W3/5nS/67e/2nE/7Ph/7/o/8Tr/8Xs/8bt/9L0/9f3/87//+r///j///r//01IQl5PP2FURkpDO1BKQ2NTQmBRQmVWR1tOQVxRRlFIP05GPlRMREpGQlhJO1dLQFVKQFhORU1FPqqqqqKiopqamo6OjoKCgn9/f3x8fGZmZllZWVZWVv///wAAAAAAAAAAACH5BAEAADwALAAAAAAUABQAQAZlQJ5wSCwahZ+Ap+PhaCySCGPSkh2v2Kx2SLvZvmDbrTbbms/H1QZzwVQoD8dCASHh0Pi8fs/n5T4sgR8jKzAoISY6RyMZCQgJDQIHBgUEAyA1RjkrIjExKikvLiclJDuZfamqeEEAOw==");}
        .client_co{display:none;}
        .client_domain{text-indent:25px;}
	</style>
	<script type="text/javascript">
    function $(id){
        return document.getElementById(id);
    }
	function setActiveA($id){
		var query = location.search+"&";
		var div = document.getElementById($id);
		if(div){
			var arr = div.getElementsByTagName("a");
			for(var i=0; i<arr.length; i++){
				var a = arr[i];
				if((a.href+"&").indexOf(query)!==-1){
					a.className = "active";
				}
			}
		}
	}
	function rename(id,info){
		var newInfo = prompt("������������"+id+"��������", info);
		if(newInfo){
			newInfo = newInfo.replace(/[\r\n\'"<>\?&#\^\$\+=\[\]\|\\\/]/g, "");
		}
		if(newInfo && newInfo!=info){
			document.getElementById("hiddenFrame").src="?page=rename&id="+id+"&info="+newInfo;
		}
		return false;
	}
    function foldit(clientId){
        var ico = $("ico_"+clientId), folded = ico.className=="client_fold", content = $("co_"+clientId);
        folded = !folded;
        ico.className = folded ? "client_fold" : "client_unfold";
        content.style.display = folded ? "none" : "table-row-group";
    }
	</script>
	</head>
	<body>
	<div id="top-menu" class="menu">
	<a href="?page=active">�����</a><b>|</b><a href="?page=tj&tjid=v">�ÿ�ͳ��</a>
	<a href="?page=tj&tjid=v_faq">�ʴ�ÿ�ͳ��</a>
	<a href="?page=tj&tjid=v_video">Ӱ���ÿ�ͳ��</a>
	<!-- a href="?page=tj&tjid=play">Ӱ������ͳ��</a -->
	<a href="?page=tj&tjid=3t">ֱ������ͳ��</a><b>|</b><a href="?page=log">�鿴��־</a>
	</div>';
	if($page=='tj'){
		$tjid = isset($_GET['tjid']) ? $_GET['tjid'] : 'v';
		$clientidParam = isset($_GET['clientid']) ? $_GET['clientid'] : '';
		$files = scandir($sync_dir);
		$arr = array();
		foreach($files as $filename){
			if(substr($filename,0,3)!='~c_') continue;
			$clientId = substr($filename,3,-4);
			$client = get_client_info($clientId);
			$arr[$client] = "<a href='?page={$page}&tjid={$tjid}&clientid={$clientId}'" .($clientidParam==$clientId?' class="active"':''). ">{$client}</a>";
		}
		ksort($arr, SORT_STRING | SORT_FLAG_CASE);
		echo "<div id='client-menu' class='menu'><a href='?page={$page}&tjid={$tjid}&clientid='" .(empty($_GET['clientid'])?' class="active"':''). ">ȫ������</a>";
		echo implode("\n", $arr);
		echo "</div>";
	}
	echo '<script type="text/javascript">setActiveA("top-menu");</script>';
}

function showLog($all){
	global $sync_server_files;
	showHead();
	if(!file_exists($sync_server_files['log'])){
		echo '������־';
		return;
	}
	$lines = file($sync_server_files['log'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	$count = count($lines);
	if($count>500){
		unset($lines[0]);
	}
	$lines = array_reverse($lines);

	if(!$all){
		$lines = array_slice($lines, 0, 100);
	}
	echo "<div class='tips'>�����������500k��1M��־</div>";
	echo implode('<br>', $lines);
	if(!$all && $count>100){
		echo "<hr><a href='?page=alllog'>��ʾ������־ ����{$count}����</a>";
	}
}

function showCounter(){
	global $sync_dir, $upload_options, $address;
	showHead();
	$tjid = isset($_GET['tjid']) ? $_GET['tjid'] : '';
	if(!isset($upload_options[$tjid])){
		showError();
	}
	$option = $upload_options[$tjid];

	$clientId = isset($_GET['clientid']) ? $_GET['clientid'] : '';
	if($clientId){
		$client = get_client_info($clientId);
		$data = unserialize(file_get_contents("{$sync_dir}/~c_{$clientId}.dat"));

		if($tjid=='v' && !empty($data['~counter_visit_address.dat'])){
			$address_counter = $data['~counter_visit_address.dat'];
		}

		$data = $data[$option['file']];
		//ͳ�����ݲ�����file�ļ����Ϊ����data��
		unset($option['file']);
		$option['data'] = $data;

	}else{
		$now = time();
		$today = intval(date('Ymd'));
		$thism = intval(date('Ym'));
		$lastm = intval(date('Ym',strtotime("-1 month")));
		$hour48hAgo = intval(date('YmdH',strtotime("-2 day")));
		$allData = array(
			'all'=>0,
			'lastm'=>array(),
			'thism'=>array(),
		    'date'=>'',
			'hour'=>array(),
			'domains'=>array(), //domain => array(�ܷ��������������·ݣ����·����������������ڣ����շ�������������ʱ�䣬��ע˵��)���鿴ʱ�������������ڼ�����û�˷�����
			$thism => 0,
			$lastm => 0,
		);
		$address_counter = array();

		$files = scandir($sync_dir);
		foreach($files as $filename){
			if(substr($filename,0,3)!='~c_') continue;
			$clientId = substr($filename,3,-4);
			$fullfile = "{$sync_dir}/{$filename}";
			if($now-filemtime($fullfile)>86400*62) continue;
			$data = unserialize(file_get_contents($fullfile));

			if($tjid=='v' && !empty($data['~counter_visit_address.dat'])){
				//�ϲ�address_counter
				foreach($data['~counter_visit_address.dat'] as $k=>$v){
				    $arr = isset($address_counter[$k]) ? $address_counter[$k] : array();
				    foreach($v as $k2=>$v2){
				        $arr[$k2] = isset($arr[$k2]) ? ($arr[$k2]+$v2) : $v2;
				    }
				    $address_counter[$k] = $arr;
				}
			}

			$countFile = $option['file'];
			$data = $data[$countFile];
			$allData['date'] = strcmp($allData['date'], $data['date'])<0 ? $data['date'] : $allData['date'];
			$allData['all'] += $data['all'];
			$month = intval($data['date']/100);

			if($month==$thism){
				foreach($data['lastm'] as $day=>$num){
					if(!isset($allData['lastm'][$day])) $allData['lastm'][$day]=0;
					$allData['lastm'][$day] += $num;
				}
				foreach($data['thism'] as $day=>$num){
					if(!isset($allData['thism'][$day])) $allData['thism'][$day]=0;
					$allData['thism'][$day] += $num;
				}
			}elseif($month==$lastm){
				foreach($data['thism'] as $day=>$num){
					if(!isset($allData['lastm'][$day])) $allData['lastm'][$day]=0;
					$allData['lastm'][$day] += $num;
				}
			}
			foreach($data['hour'] as $hour=>$num){
				if($hour<$hour48hAgo) continue;
				if(!isset($allData['hour'][$hour])) $allData['hour'][$hour]=0;
				$allData['hour'][$hour] += $num;
			}
			foreach($data['domains'] as $domain=>$arr){
				//if($now-$arr[5]>86400*62) continue;
				$client = get_client_info($clientId);
				$allData['domains']["{$client} -- {$domain}"] = $arr;
			}
			if(!isset($allData['hour'][$hour])) $allData['hour'][$hour]=0;
			$allData[$thism] += empty($data[$thism]) ? 0 : $data[$thism];
			$allData[$lastm] += empty($data[$lastm]) ? 0 : $data[$lastm];
		}

		//ͳ�����ݲ�����file�ļ����Ϊ����data��
		unset($option['file']);
		$option['data'] = $allData;
	}

	define('BAR_ENABLE_BUTTONS', false);
	if(!include(APPDIR.'/include/counter.inc.php')){
		echo 'File not found: counter.inc.php';
	}
}

/**
 * ������ʾʱ�Ż�ѷ���ͳ����Ļ�����M�кϲ�������¼�������ļ���
 * �����ļ���ʽ��array(clientid => array(mtime=>0, domain1=>lasttime, domain2=>lasttime, ...), ...)
 */
function showActive(){
	global $sync_dir, $sync_server_files;
	showHead();
	$activeFile = $sync_server_files['active'];
	$allActive = file_exists($activeFile) ? unserialize(file_get_contents($activeFile)) : array();
	$now = time();
	$day_48hAgo = intval(date('Ymd',strtotime("-2 day")));
	if(!file_exists($activeFile) || $now-filemtime($activeFile)>60){
		//60���ڸ���һ��
		$files = scandir($sync_dir);
		foreach($files as $filename){
			if(substr($filename,0,3)=='~c_'){
				$clientId = substr($filename,3,-4);
				$fullname = "{$sync_dir}/{$filename}";
				if($now-filemtime($fullname)>86400) continue; //����ʾδ�ʱ�䳬��һ���client
				$data = array();
				$counters = unserialize(file_get_contents($fullname));
				foreach($counters as $counter){
					if(empty($counter['domains'])) continue;
					if($counter['date']<$day_48hAgo) continue; //����ʾδ�ʱ�䳬��һ���client
					foreach($counter['domains'] as $domain=>$v){
						if($now-$v[5]>86400) continue;
						$data[$domain] = isset($data[$domain]) ? max($data[$domain],$v[5]) : $v[5];
					}
				}
				$allActive[$clientId] = $data;
			}
		}
		//���ֻ����ļ�
		file_put_contents($activeFile, serialize($allActive), LOCK_EX);
	}

	echo '<iframe id="hiddenFrame" style="display:none;"></iframe>';
	echo '<div class="tips">����ʾ1�����й����ʵ�����</div>';
	echo '<table class="t1" style="margin-top:5px;"><thead><tr><th>����</th><th>����</th><th>���������ʱ��</th></tr></thead><tbody>';
	foreach($allActive as $clientId => $data){
		$client = get_client_info($clientId);
		$block = '';
		$index = 0;
		foreach($data as $k => $v){
			$hour = intval(($now-$v)/3600);
			if($hour<1){
				$v = '1Сʱ��';
			}elseif($hour>=24){
				$v = '1���';
			}else{
				$v = "{$hour}��Сʱ";
			}
			$block .= "<tr><td class='client_domain'>{$client}</td><td>{$k}</td><td>{$v}</td></tr>";
		}
		echo "<tr>
                <td colspan='3'><b id='ico_{$clientId}' class='client_fold' onclick='foldit(\"{$clientId}\");'></b>{$client}
                <button onclick=\"return rename('{$clientId}','{$client}');\">����</button></td>
              </tr>";
		echo "<tbody id='co_{$clientId}' class='client_co'>{$block}</tbody>";
	}
	echo '</tbody></table>';
}

//=====================================================================================
//================ server =============================================================
//=====================================================================================


//�����ͻ������󣨸�����������ִ�в�ͬ�Ĵ������̣�
function sync_server_dispose(){
	global $sync_server_files;
	//������������
	if(!function_exists('gzencode') || !function_exists('gzdecode')) exit('no gz!');
	$clientHome = $_SERVER["HTTP_REFERER"];
	$pwd = md5_16(DEFAULT_JYG_PASSWORD.$clientHome);
	$data = decrypt_data($_POST['data'], $pwd);
	if(!is_array($data) || !isset($data['gz'],$data['client_name'],$data['client_id'],$data['api'],$data['content'],$data['_'])){
		$error = "[err] {$clientHome} �������ݸ�ʽ����";
		add_sync_log($error);
		exit($error);
	}
	$client = get_client_info($data['client_id'],$data['client_name']);
	if(abs(time()-$data['_'])>3600){
		$error = "[err] {$client} ʱ��������1Сʱ";
		add_sync_log($error);
		exit($error);
	}
	if(empty($data['content'])){
		$error = "[err] {$client} �������ݲ���Ϊ��";
		add_sync_log($error);
		exit($error);
	}
	$data['client'] = $client;
	$data['client_home'] = $clientHome;
	$data['pwd'] = $pwd;

	//[�ӿ�]
	switch($data['api']){
		case 'download':
			sync_server_dispose_download($data);
			break;
		case 'upload':
			sync_server_dispose_upload($data);
			break;
		default:
			exit('[err] unsupported api');
	}
}

/**
 * [�ӿ�] ��Ӧ�����ļ�����
 * ��������ʱ�ᴫ�ݹ���client�˵��ļ�md5����ֵ�����˵�md5���ᱻ�����������Ƚϣ���ͬʱ����Ҫ����
 */
function sync_server_dispose_download($data){
	global $sync_dir, $sync_server_files, $all_upload_files, $all_download_files;

	//��������ʱ�ᴫ�ݹ���client�˵��ļ�md5��
	$md5File = $sync_server_files['md5'];
	if(file_exists($md5File)){
		$md5Mtime = filemtime($md5File);
	}else{
		$md5Mtime = 0;
	}

	if(time()-$md5Mtime>60){
		if(file_exists($md5File) && filesize($md5File)>0){
			$md5Cache = unserialize(file_get_contents_safe($md5File));
		}else{
			$md5Cache = array();
		}
		//���Ҫ�����ļ���md5ֵ�Ƿ���Ҫ����
		$changed = false;
		touch($md5File);
		foreach($all_download_files as $filename){
			$fullfile = $sync_dir.'/'.$filename;
			if(!file_exists($fullfile)){
				$changed = isset($md5Cache[$filename]);
				unset($md5Cache[$filename]);
			}else{
				$mtime = filemtime($fullfile);
				if(!isset($md5Cache[$filename]) || $mtime!=$md5Cache[$filename]['mtime']){
					$changed = true;
					$md5Cache[$filename] = array('mtime'=>$mtime, 'md5'=>md5_file($fullfile));
				}
			}
		}
		foreach($md5Cache as $filename=>$v){
			if(!in_array($filename, $all_download_files)){
				$changed = true;
				unset($md5Cache[$filename]);
			}
		}
		if($changed){
			file_put_contents($md5File, serialize($md5Cache), LOCK_EX);
		}
	}

	$updateFiles = array();
	foreach($data['content'] as $filename=>$clientMd5){
		if(!isset($md5Cache[$filename]) || $clientMd5==$md5Cache[$filename]['md5']) continue;
		$fullfile = $sync_dir.'/'.$filename;
		if(!file_exists($fullfile)) continue;
		$content = file_get_contents_safe($fullfile);
		if(!$content) continue;
		$updateFiles[$filename] = $content;
	}
	if(empty($updateFiles)) exit('304');
	$updateFileNames = implode(', ',array_keys($updateFiles));
	$response = encrypt_data($updateFiles, $data['pwd'], $data['gz']);
	echo $response;

	//��¼��־
	add_sync_log("[ok]  {$data['client']} ������ {$updateFileNames}");
	exit;
}

/**
 * [�ӿ�] ���շֻ�ͳ������
 */
function sync_server_dispose_upload($data){
	global $sync_dir, $all_upload_files;
	$now = time();
	$clientId = $data['client_id'];
	$client = $data['client'];

	$clientCounterFile = $sync_dir."/~c_{$clientId}.dat";
	$clientCounters = array();
	if(file_exists($clientCounterFile)){
		$clientCounters = unserialize(file_get_contents_safe($clientCounterFile));
		if(!is_array($clientCounters)) $clientCounters=array();
	}

	$files = $data['content'];
	$uploadedFiles = array();
	foreach($files as $filename=>$content){
		if(!in_array($filename, $all_upload_files) || empty($content)) continue;
		$arr = unserialize($content);
		$clientCounters[$filename] = $arr;
		$uploadedFiles[] = $filename;
	}

	file_put_contents($clientCounterFile, serialize($clientCounters), LOCK_EX);

	add_sync_log("[ok]  {$client} �ϴ��� " . implode(', ',$uploadedFiles));
	echo 'ok';
	exit;
}

/**
 * ��¼��Ӧ��־
 */
function add_sync_log($log){
	global $sync_server_files;
	$logFile = $sync_server_files['log'];
	file_put_contents($logFile, date('Y-m-d H:i:s')." {$log}\r\n", FILE_APPEND | LOCK_EX);
	if(filesize($logFile)>1024*1024){
		$handle = fopen($logFile, 'r');
		if($handle!==false){
			fseek($handle, -512*1024, SEEK_END);
			$content = fread($handle, 512*1024);
			fclose($handle);
			file_put_contents($logFile, $content, LOCK_EX);
		}
	}
}

/**
 * ��ȡ�ֻ�������
 * @param string $client_id
 * @param string $client_name
 */
function get_client_info($client_id, $client_name=''){
	static $client_table = null;
	if($client_table===null){
		global $sync_server_files;
		$tableFile = $sync_server_files['client'];
		if(file_exists($tableFile)){
		   $client_table = unserialize(file_get_contents_safe($tableFile));
		}else{
		   $client_table = array();
		}
	}
	$ret = isset($client_table[$client_id]) ? $client_table[$client_id] : $client_id;
	if($client_name){
		$ret .= "({$client_name})";
	}
	return $ret;
}

/**
 * Ϊ�ֻ�����
 * @param string $client_id
 * @param string $client_name
 */
function set_client_info($client_id, $client_name){
	if(!empty($client_id) && !empty($client_name)){
		global $sync_server_files;
		$tableFile = $sync_server_files['client'];
		if(file_exists($tableFile)){
		   $client_table = unserialize(file_get_contents_safe($tableFile));
		}else{
		   $client_table = array();
		}
		$client_table[$client_id] = $client_name;
		file_put_contents($tableFile, serialize($client_table), LOCK_EX);
	}
	echo '<script type="text/javascript">parent.location.reload();</script>';
	exit;
}


//=====================================================================================
//================ client =============================================================
//=====================================================================================


/**
 * Ϊÿ������������һ��ΨһID���־û���/data/~id.dat�ļ���
 */
function get_client_id(){
	global $sync_client_files;
	static $id = null;
	if($id){
		return $id;
	}
	$idFile = $sync_client_files['client'];
	if(file_exists($idFile)){
		$id = trim(file_get_contents($idFile));
	}
	if(!$id || strlen($id)!=16){
		$id = substr(md5(uniqid(serialize($_SERVER),true)),8,16);
		file_put_contents($idFile, $id, LOCK_EX);
	}
	return $id;
}

/**
 * ÿ�ո���һ��data�ļ�
 */
function sync_client_download(){
	//������������
	global $all_download_files, $sync_client_files;
	if(DEBUGING===0 && !in_array(date('G'),array(23,0,1,2,3,4,5))) return false; //ֻ���⼸���ӵ��ڼ�����

	//�������־�ļ�
	$markFile = $sync_client_files['mark_download'];
	$lastMarkTime = get_mark_time($markFile);
	if(time()-$lastMarkTime<43200) return false; //1Сʱ�ڲ��ظ�����

	//׼��Ҫ�ύ�����ݣ��ļ��������ʱ����б���
	$fileContents = array();
	foreach($all_download_files as $filename){
		$fullfile = DATADIR.'/'.$filename;
		if(file_exists($fullfile)){
			$fileContents[$filename]=md5_file($fullfile);
		}
	}

	//�ϴ�
	$response = post_encrypted_data('download',$fileContents);
	if($response == 'ok'){
		return true;
	}elseif($response=='304'){
		//û�仯
		if(DEBUGING>1) echo '// 304';
		return false;
	}elseif($response==''){
		//������������10���Ӻ�����
		touch($markFile, time()-86400+600);
		if(DEBUGING>1) echo '// error response 101';
		return false;
	}elseif(substr($response,0,5)=='[err]'){
		touch($markFile, time()-86400+600);
		if(DEBUGING>1) echo '// error response ' . $response;
		return false;
	}elseif($response[0]!='1' && $response[0]!='1'){
		if(DEBUGING>1) echo '// error response 102';
		return false;
	}else{
		//������Ӧ����
		$clientHome = Url::getCurrentScheme().'://'.Url::getCurrentSite();
		$pwd = md5_16(DEFAULT_JYG_PASSWORD.$clientHome);
		$data = decrypt_data($response, $pwd);
		if(!is_array($data)) {
			if(DEBUGING>1) echo '// error response 103';
			return false;
		}

		//���±����ļ�
		$updatedFilenames = array();
		foreach($data as $filename=>$content){
			if(in_array($filename, $all_download_files)){
				$fullfile = DATADIR.'/'.$filename;
				file_put_contents($fullfile, $content, LOCK_EX);
				$updatedFilenames[] = $filename;
			}
		}
		if(DEBUGING>1) echo "// updated " . implode(', ', $updatedFilenames);
		return true;
	}
}

/**
 * ÿ1Сʱ�ϴ�һ�η���ͳ��
 */
function sync_client_upload(){
	//������������
	global $all_upload_files, $sync_client_files;

	//�������־�ļ�
	$markFile = $sync_client_files['mark_upload'];
	$lastMarkTime = get_mark_time($markFile);
	if(time()-$lastMarkTime<1800) return false; //��Сʱ�ڲ��ظ�����

	get_address_counter();

	//׼��Ҫ�ύ�����ݣ��ļ��������ݵ��б���
	$now = time();
	$fileContents = array();
	foreach($all_upload_files as $filename){
		$fullname = DATADIR.'/'.$filename;
		if(file_exists($fullname) && filemtime($fullname)>$lastMarkTime){
			$content = file_get_contents_safe($fullname);
			if($content) {
				//���˵�����һ������������ͳ��
				$changed = false;
				$arr = unserialize($content);
				if(isset($arr['domains'])){
					foreach($arr['domains'] as $k=>$v){
						if($now-$v[5]>86400*DOMAIN_MAX_DAYS){
							unset($arr['domains'][$k]);
							$changed = true;
						}
					}
					if($changed){
						$content = serialize($arr);
					}
				}
				//Ҫ�ϴ������ݣ����Ҫ���ϴ������M�й��ˣ����ڴ˴���
				$fileContents[$filename] = $content;
			}
		}
	}
	if(empty($fileContents)){
		if(DEBUGING>1) echo '// nothing for upload';
		return false;
	}

	//�ϴ�
	$response = post_encrypted_data('upload',$fileContents);
	if($response == 'ok'){
		echo '// ok';
		return true;
	}elseif(substr($response,0,5)=='[err]'){
		if(DEBUGING>1) echo '// error response ' . $response;
	}else{
		if(DEBUGING>1) echo '// error response 201';
	}
	//������������10���Ӻ�����
	touch($markFile, time()-1800+600);
	return false;
}


function showError(){
	header('HTTP/1.1 404 Not Found');
	readfile(DATADIR."/error/404.txt");
	exit;
}

/**
 * ���״̬������������
 */
function check_sync_server($page){
    global $config;
	if(empty($page) || empty($config['sync_server'])){
		showError();
	}elseif(DEBUGING<2){
		if(strpos($config['sync_server'],'/'.Url::getCurrentSite().'/')===false){
		    //�����ǰ��������sync_server
		    if($page!='client'){
    			//ֻ����client
    			showError();
		    }
		}else{
		    //�����sync_server
		    if($page=='client'){
    			//������client֮������ж���
    			showError();
		    }
		}
	}
	return true;
}

/**
 * ��������־�ļ�����ʱ��
 */
function get_mark_time($markFile){
	if(file_exists($markFile)){
		$mtime = filemtime($markFile);
	}else{
		$mtime = 0;
	}
	touch($markFile); //�����ڸ����ڼ䱻��������ͬʱ����
	return $mtime;
}

/**
 * �ϴ��ӿ�����
 */
function post_encrypted_data($api, $content){
	global $config;

	$clientHome = Url::getCurrentScheme().'://'.Url::getCurrentSite();
	$pwd = md5_16(DEFAULT_JYG_PASSWORD.$clientHome);
	$data = array(
		'gz'=>function_exists('gzencode') && function_exists('gzdecode'),
		'client_name'=>$_SERVER['SERVER_NAME'],
		'client_id'=>get_client_id(),
		'api'=>$api,
		'content'=>$content,
		'_'=>time(),
	);
	$data = encrypt_data($data, $pwd);

	$option = array('timeout'=>60, 'referer'=>$clientHome, 'proxy'=>$config['proxy']);
	if(DEBUGING>1) $option['cookie'] = $_COOKIE;

	$server = $config['sync_server'];
	if(substr($server,-1,1)!='/'){
		$server .= '/';
	}
	return http_post("{$server}sync.php?page=server", "data={$data}", $option);
}


//=====================================================================================
//================ ���� =============================================================
//=====================================================================================


/**
 * �����ɿͻ�����������ݻ��߷��������ص�����
 */
function encrypt_data($data, $pwd, $gz=null){
	$ret = serialize($data);
	$ret = (($gz!==null && $gz) || (isset($data['gz']) && $data['gz'])) ? ('1'.gzencode($ret,9)) : ('0'.$ret);
	$ret = $ret ^ str_pad($pwd,strlen($ret),$pwd);
	$ret = str_encrypt($ret);
	return $ret;
}

/**
 * �����ɿͻ�����������ݻ��߷��������ص�����
 */
function decrypt_data($data, $pwd){
	$data = str_decrypt($data);
	$data = $data ^ str_pad($pwd,strlen($data),$pwd);
	$gz = $data[0]=='1';
	$data = substr($data, 1);
	if($gz) $data = gzdecode($data);
	$data = unserialize($data);
	return $data;
}
